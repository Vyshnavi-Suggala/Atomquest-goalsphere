import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { DataProvider } from "@/contexts/DataContext";
import { Layout } from "@/components/Layout";

import Login from "@/pages/Login";
import EmployeeDashboard from "@/pages/employee/Dashboard";
import EmployeeGoals from "@/pages/employee/Goals";
import GoalForm from "@/pages/employee/GoalForm";
import CheckIn from "@/pages/employee/CheckIn";
import Notifications from "@/pages/employee/Notifications";
import ManagerDashboard from "@/pages/manager/Dashboard";
import ManagerApprovals from "@/pages/manager/Approvals";
import ManagerTeam from "@/pages/manager/Team";
import ManagerReviews from "@/pages/manager/Reviews";
import AdminDashboard from "@/pages/admin/Dashboard";
import AdminUsers from "@/pages/admin/Users";
import AdminCycles from "@/pages/admin/Cycles";
import AdminAnalytics from "@/pages/admin/Analytics";
import AdminAudit from "@/pages/admin/Audit";
import AdminReports from "@/pages/admin/Reports";
import AdminEscalations from "@/pages/admin/Escalations";
import Leaderboard from "@/pages/Leaderboard";

function PrivateRoute({ component: Component, roles }: { component: React.ComponentType; roles?: string[] }) {
  const { currentUser, isAuthenticated } = useAuth();
  if (!isAuthenticated) return <Redirect to="/login" />;
  if (roles && currentUser && !roles.includes(currentUser.role)) {
    if (currentUser.role === "admin") return <Redirect to="/admin/dashboard" />;
    if (currentUser.role === "manager") return <Redirect to="/manager/dashboard" />;
    return <Redirect to="/employee/dashboard" />;
  }
  return <Layout><Component /></Layout>;
}

function DefaultRedirect() {
  const { currentUser, isAuthenticated } = useAuth();
  if (!isAuthenticated) return <Redirect to="/login" />;
  if (currentUser?.role === "admin") return <Redirect to="/admin/dashboard" />;
  if (currentUser?.role === "manager") return <Redirect to="/manager/dashboard" />;
  return <Redirect to="/employee/dashboard" />;
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/" component={DefaultRedirect} />

      {/* Employee Routes */}
      <Route path="/employee/dashboard">
        <PrivateRoute component={EmployeeDashboard} roles={["employee", "manager", "admin"]} />
      </Route>
      <Route path="/employee/goals/new">
        <PrivateRoute component={GoalForm} roles={["employee", "manager", "admin"]} />
      </Route>
      <Route path="/employee/goals/:id/edit">
        <PrivateRoute component={GoalForm} roles={["employee", "manager", "admin"]} />
      </Route>
      <Route path="/employee/goals">
        <PrivateRoute component={EmployeeGoals} roles={["employee", "manager", "admin"]} />
      </Route>
      <Route path="/employee/checkin">
        <PrivateRoute component={CheckIn} roles={["employee", "manager", "admin"]} />
      </Route>
      <Route path="/employee/notifications">
        <PrivateRoute component={Notifications} roles={["employee", "manager", "admin"]} />
      </Route>

      {/* Manager Routes */}
      <Route path="/manager/dashboard">
        <PrivateRoute component={ManagerDashboard} roles={["manager", "admin"]} />
      </Route>
      <Route path="/manager/approvals">
        <PrivateRoute component={ManagerApprovals} roles={["manager", "admin"]} />
      </Route>
      <Route path="/manager/team">
        <PrivateRoute component={ManagerTeam} roles={["manager", "admin"]} />
      </Route>
      <Route path="/manager/reviews">
        <PrivateRoute component={ManagerReviews} roles={["manager", "admin"]} />
      </Route>

      {/* Admin Routes */}
      <Route path="/admin/dashboard">
        <PrivateRoute component={AdminDashboard} roles={["admin"]} />
      </Route>
      <Route path="/admin/users">
        <PrivateRoute component={AdminUsers} roles={["admin"]} />
      </Route>
      <Route path="/admin/cycles">
        <PrivateRoute component={AdminCycles} roles={["admin"]} />
      </Route>
      <Route path="/admin/analytics">
        <PrivateRoute component={AdminAnalytics} roles={["admin"]} />
      </Route>
      <Route path="/admin/audit">
        <PrivateRoute component={AdminAudit} roles={["admin"]} />
      </Route>
      <Route path="/admin/reports">
        <PrivateRoute component={AdminReports} roles={["admin"]} />
      </Route>
      <Route path="/admin/escalations">
        <PrivateRoute component={AdminEscalations} roles={["admin"]} />
      </Route>

      {/* Shared */}
      <Route path="/leaderboard">
        <PrivateRoute component={Leaderboard} />
      </Route>

      {/* Fallback */}
      <Route>
        <DefaultRedirect />
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <DataProvider>
      <AuthProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
      </AuthProvider>
    </DataProvider>
  );
}

export default App;
