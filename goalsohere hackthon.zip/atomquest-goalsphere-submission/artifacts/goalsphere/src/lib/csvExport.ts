import type { Goal, User, PerformanceRating } from "@/data/mockData";
import { calculateGoalProgress } from "./progress";

function escapeCSV(value: string | number | undefined): string {
  if (value === undefined || value === null) return "";
  const str = String(value);
  if (str.includes(",") || str.includes('"') || str.includes("\n")) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function buildCSV(headers: string[], rows: string[][]): string {
  const headerLine = headers.map(escapeCSV).join(",");
  const dataLines = rows.map(row => row.map(escapeCSV).join(","));
  return [headerLine, ...dataLines].join("\n");
}

export function downloadCSV(content: string, filename: string): void {
  const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function exportPlannedVsActual(goals: Goal[], users: User[]): void {
  const headers = ["Employee", "Department", "Goal Title", "Thrust Area", "UoM", "Target", "Actual", "Progress %", "Status", "Achievement Status", "Deadline"];
  const rows = goals.map(g => {
    const user = users.find(u => u.id === g.employeeId);
    return [
      user?.name ?? "",
      user?.department ?? "",
      g.title,
      g.thrustArea,
      g.unitOfMeasurement,
      String(g.target),
      String(g.actualAchievement ?? "N/A"),
      String(Math.round(calculateGoalProgress(g))) + "%",
      g.status,
      g.achievementStatus,
      g.deadline,
    ];
  });
  downloadCSV(buildCSV(headers, rows), "planned-vs-actual.csv");
}

export function exportEmployeePerformance(users: User[], goals: Goal[], ratings: PerformanceRating[]): void {
  const headers = ["Employee", "Department", "Job Title", "Total Goals", "Approved Goals", "Overall Progress %", "Latest Rating"];
  const rows = users.filter(u => u.role === "employee").map(u => {
    const empGoals = goals.filter(g => g.employeeId === u.id && (g.status === "Approved" || g.status === "Locked"));
    const totalGoals = goals.filter(g => g.employeeId === u.id).length;
    const approved = empGoals.length;
    const progress = empGoals.length > 0
      ? Math.round(empGoals.reduce((sum, g) => sum + calculateGoalProgress(g) * g.weightage / 100, 0))
      : 0;
    const latestRating = ratings.filter(r => r.employeeId === u.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
    return [u.name, u.department, u.jobTitle, String(totalGoals), String(approved), String(progress) + "%", latestRating ? String(latestRating.rating) + "/5" : "N/A"];
  });
  downloadCSV(buildCSV(headers, rows), "employee-performance.csv");
}

export function exportDepartmentAnalytics(users: User[], goals: Goal[]): void {
  const depts = Array.from(new Set(users.map(u => u.department)));
  const headers = ["Department", "Total Employees", "Total Goals", "Approved Goals", "Submitted Goals", "Draft Goals", "Avg Progress %"];
  const rows = depts.map(dept => {
    const deptUsers = users.filter(u => u.department === dept && u.role === "employee");
    const deptGoals = goals.filter(g => deptUsers.some(u => u.id === g.employeeId));
    const approved = deptGoals.filter(g => g.status === "Approved" || g.status === "Locked");
    const avgProgress = approved.length > 0
      ? Math.round(approved.reduce((s, g) => s + calculateGoalProgress(g), 0) / approved.length)
      : 0;
    return [
      dept,
      String(deptUsers.length),
      String(deptGoals.length),
      String(deptGoals.filter(g => g.status === "Approved" || g.status === "Locked").length),
      String(deptGoals.filter(g => g.status === "Submitted").length),
      String(deptGoals.filter(g => g.status === "Draft").length),
      String(avgProgress) + "%",
    ];
  });
  downloadCSV(buildCSV(headers, rows), "department-analytics.csv");
}
