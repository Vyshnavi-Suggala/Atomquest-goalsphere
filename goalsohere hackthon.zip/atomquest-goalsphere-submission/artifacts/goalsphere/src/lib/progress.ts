import type { Goal } from "@/data/mockData";

export function calculateGoalProgress(goal: Goal): number {
  const achievement = goal.actualAchievement ?? 0;
  const target = goal.target;

  if (goal.unitOfMeasurement === "Numeric") {
    if (target === 0) return 100;
    return Math.min(100, (achievement / target) * 100);
  }

  if (goal.unitOfMeasurement === "Percentage") {
    if (achievement === 0) return 0;
    return Math.min(100, (target / achievement) * 100);
  }

  if (goal.unitOfMeasurement === "Timeline") {
    if (goal.achievementStatus === "Completed") return 100;
    const deadline = new Date(goal.deadline).getTime();
    const start = new Date(goal.createdAt).getTime();
    const now = Date.now();
    if (now >= deadline) return 0;
    const total = deadline - start;
    const elapsed = now - start;
    return Math.max(0, Math.min(100, 100 - (elapsed / total) * 100));
  }

  if (goal.unitOfMeasurement === "ZeroBased") {
    return achievement === 0 ? 100 : 0;
  }

  return 0;
}

export function calculateOverallProgress(goals: Goal[]): number {
  const approvedGoals = goals.filter(g => g.status === "Approved" || g.status === "Locked");
  if (approvedGoals.length === 0) return 0;

  const totalWeightage = approvedGoals.reduce((sum, g) => sum + g.weightage, 0);
  if (totalWeightage === 0) return 0;

  const weightedProgress = approvedGoals.reduce((sum, g) => {
    const progress = calculateGoalProgress(g);
    return sum + (progress * g.weightage) / totalWeightage;
  }, 0);

  return Math.round(weightedProgress);
}

export function getTotalWeightage(goals: Goal[]): number {
  return goals.reduce((sum, g) => sum + g.weightage, 0);
}

export function validateGoalWeightage(goals: Goal[], newWeightage: number, excludeId?: string): {
  isValid: boolean;
  message: string;
  total: number;
} {
  const existingGoals = goals.filter(g => g.id !== excludeId);
  const existingTotal = existingGoals.reduce((sum, g) => sum + g.weightage, 0);
  const newTotal = existingTotal + newWeightage;

  if (newWeightage < 10) {
    return { isValid: false, message: "Minimum weightage per goal is 10%", total: newTotal };
  }

  if (newTotal > 100) {
    return { isValid: false, message: `Total weightage would exceed 100% (current: ${existingTotal}%, adding: ${newWeightage}%)`, total: newTotal };
  }

  return { isValid: true, message: "", total: newTotal };
}
