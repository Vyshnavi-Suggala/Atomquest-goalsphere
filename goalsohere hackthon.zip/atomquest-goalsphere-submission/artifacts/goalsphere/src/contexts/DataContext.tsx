import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import type { Goal, User, GoalCycle, Notification, AuditLog, PerformanceRating } from "@/data/mockData";
import { getStorageItem, setStorageItem } from "@/lib/storage";
import { seedLocalStorage } from "@/data/mockData";

interface DataContextType {
  users: User[];
  goals: Goal[];
  cycles: GoalCycle[];
  notifications: Notification[];
  auditLogs: AuditLog[];
  ratings: PerformanceRating[];

  addGoal: (goal: Goal) => void;
  updateGoal: (id: string, updates: Partial<Goal>) => void;
  deleteGoal: (id: string) => void;

  updateCycle: (id: string, updates: Partial<GoalCycle>) => void;

  addNotification: (n: Notification) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: (userId: string) => void;

  addAuditLog: (log: AuditLog) => void;

  addRating: (rating: PerformanceRating) => void;
  updateRating: (id: string, updates: Partial<PerformanceRating>) => void;
}

const DataContext = createContext<DataContextType | null>(null);

export function DataProvider({ children }: { children: ReactNode }) {
  useEffect(() => { seedLocalStorage(); }, []);

  const [users] = useState<User[]>(() => getStorageItem<User[]>("aq_users", []));
  const [goals, setGoals] = useState<Goal[]>(() => getStorageItem<Goal[]>("aq_goals", []));
  const [cycles, setCycles] = useState<GoalCycle[]>(() => getStorageItem<GoalCycle[]>("aq_cycles", []));
  const [notifications, setNotifications] = useState<Notification[]>(() => getStorageItem<Notification[]>("aq_notifications", []));
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => getStorageItem<AuditLog[]>("aq_audit_logs", []));
  const [ratings, setRatings] = useState<PerformanceRating[]>(() => getStorageItem<PerformanceRating[]>("aq_ratings", []));

  const persist = <T,>(key: string, data: T) => setStorageItem(key, data);

  const addGoal = (goal: Goal) => setGoals(prev => { const n = [...prev, goal]; persist("aq_goals", n); return n; });
  const updateGoal = (id: string, updates: Partial<Goal>) => setGoals(prev => {
    const n = prev.map(g => g.id === id ? { ...g, ...updates, updatedAt: new Date().toISOString().split("T")[0] } : g);
    persist("aq_goals", n);
    return n;
  });
  const deleteGoal = (id: string) => setGoals(prev => { const n = prev.filter(g => g.id !== id); persist("aq_goals", n); return n; });

  const updateCycle = (id: string, updates: Partial<GoalCycle>) => setCycles(prev => {
    const n = prev.map(c => c.id === id ? { ...c, ...updates } : c);
    persist("aq_cycles", n);
    return n;
  });

  const addNotification = (notification: Notification) => setNotifications(prev => {
    const n = [notification, ...prev];
    persist("aq_notifications", n);
    return n;
  });
  const markNotificationRead = (id: string) => setNotifications(prev => {
    const n = prev.map(notif => notif.id === id ? { ...notif, read: true } : notif);
    persist("aq_notifications", n);
    return n;
  });
  const markAllNotificationsRead = (userId: string) => setNotifications(prev => {
    const n = prev.map(notif => notif.userId === userId ? { ...notif, read: true } : notif);
    persist("aq_notifications", n);
    return n;
  });

  const addAuditLog = (log: AuditLog) => setAuditLogs(prev => {
    const n = [log, ...prev];
    persist("aq_audit_logs", n);
    return n;
  });

  const addRating = (rating: PerformanceRating) => setRatings(prev => {
    const n = [...prev, rating];
    persist("aq_ratings", n);
    return n;
  });
  const updateRating = (id: string, updates: Partial<PerformanceRating>) => setRatings(prev => {
    const n = prev.map(r => r.id === id ? { ...r, ...updates } : r);
    persist("aq_ratings", n);
    return n;
  });

  return (
    <DataContext.Provider value={{
      users, goals, cycles, notifications, auditLogs, ratings,
      addGoal, updateGoal, deleteGoal,
      updateCycle,
      addNotification, markNotificationRead, markAllNotificationsRead,
      addAuditLog,
      addRating, updateRating,
    }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error("useData must be used within DataProvider");
  return ctx;
}
