import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import type { User } from "@/data/mockData";
import { getStorageItem, setStorageItem } from "@/lib/storage";

interface AuthContextType {
  currentUser: User | null;
  login: (user: User) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(() =>
    getStorageItem<User | null>("aq_session", null)
  );

  useEffect(() => {
    if (currentUser) {
      setStorageItem("aq_session", currentUser);
    } else {
      localStorage.removeItem("aq_session");
    }
  }, [currentUser]);

  const login = (user: User) => setCurrentUser(user);
  const logout = () => setCurrentUser(null);

  return (
    <AuthContext.Provider value={{ currentUser, login, logout, isAuthenticated: !!currentUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
