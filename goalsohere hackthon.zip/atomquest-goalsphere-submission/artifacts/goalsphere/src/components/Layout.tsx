import { useState } from "react";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard, Target, CheckSquare, Bell, BarChart3, Users, Settings,
  FileText, Shield, TrendingUp, AlertTriangle, LogOut, ChevronLeft, ChevronRight,
  ClipboardList, Award, History, Menu
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useData } from "@/contexts/DataContext";

const navItems = {
  employee: [
    { href: "/employee/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/employee/goals", label: "My Goals", icon: Target },
    { href: "/employee/checkin", label: "Check-in", icon: CheckSquare },
    { href: "/employee/notifications", label: "Notifications", icon: Bell },
  ],
  manager: [
    { href: "/manager/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/manager/approvals", label: "Approvals", icon: ClipboardList },
    { href: "/manager/team", label: "My Team", icon: Users },
    { href: "/manager/reviews", label: "Reviews", icon: CheckSquare },
    { href: "/employee/goals", label: "My Goals", icon: Target },
    { href: "/employee/notifications", label: "Notifications", icon: Bell },
  ],
  admin: [
    { href: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/admin/analytics", label: "Analytics", icon: BarChart3 },
    { href: "/admin/cycles", label: "Goal Cycles", icon: Settings },
    { href: "/admin/users", label: "User Management", icon: Users },
    { href: "/admin/reports", label: "Reports", icon: FileText },
    { href: "/admin/audit", label: "Audit Logs", icon: History },
    { href: "/admin/escalations", label: "Escalations", icon: AlertTriangle },
    { href: "/leaderboard", label: "Leaderboard", icon: Award },
  ],
};

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { currentUser, logout } = useAuth();
  const { notifications, cycles } = useData();
  const [location, navigate] = useLocation();
  const [collapsed, setCollapsed] = useState(false);

  if (!currentUser) return null;

  const items = navItems[currentUser.role] ?? [];
  const activeCycle = cycles.find(c => c.status === "Active");
  const unreadCount = notifications.filter(n => n.userId === currentUser.id && !n.read).length;

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {/* Sidebar */}
      <motion.aside
        animate={{ width: collapsed ? 64 : 240 }}
        transition={{ duration: 0.2 }}
        className="flex flex-col bg-white border-r border-gray-200 shadow-sm overflow-hidden flex-shrink-0"
      >
        {/* Logo */}
        <div className={`flex items-center border-b border-gray-100 ${collapsed ? "justify-center p-4" : "px-4 py-4"}`}>
          {!collapsed && (
            <div className="flex items-center gap-2 flex-1">
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center flex-shrink-0">
                <Target size={16} className="text-white" />
              </div>
              <div>
                <p className="text-sm font-bold text-gray-900 leading-tight">GoalSphere</p>
                <p className="text-[10px] text-gray-400 leading-tight">AtomQuest</p>
              </div>
            </div>
          )}
          {collapsed && (
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
              <Target size={16} className="text-white" />
            </div>
          )}
        </div>

        {/* Active Cycle Banner */}
        {activeCycle && !collapsed && (
          <div className="mx-3 mt-3 px-3 py-2 bg-blue-50 rounded-lg border border-blue-100">
            <p className="text-[10px] text-blue-500 font-medium uppercase tracking-wide">Active Cycle</p>
            <p className="text-xs font-semibold text-blue-700">{activeCycle.name}</p>
            <p className="text-[10px] text-blue-500">{activeCycle.phase.replace(/([A-Z])/g, ' $1').trim()}</p>
          </div>
        )}

        {/* Nav Items */}
        <nav className="flex-1 px-2 py-3 space-y-0.5 overflow-y-auto">
          {items.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href || location.startsWith(item.href + "/");
            const isNotif = item.href === "/employee/notifications";
            return (
              <Link key={item.href} href={item.href}>
                <a
                  data-testid={`nav-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                  className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors cursor-pointer relative
                    ${isActive ? "bg-blue-50 text-blue-700" : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"}`}
                >
                  <Icon size={16} className="flex-shrink-0" />
                  {!collapsed && <span className="flex-1 truncate">{item.label}</span>}
                  {!collapsed && isNotif && unreadCount > 0 && (
                    <span className="ml-auto bg-blue-600 text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                      {unreadCount > 9 ? "9+" : unreadCount}
                    </span>
                  )}
                </a>
              </Link>
            );
          })}

          {currentUser.role !== "admin" && (
            <Link href="/leaderboard">
              <a className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors cursor-pointer ${location === "/leaderboard" ? "bg-blue-50 text-blue-700" : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"}`}>
                <Award size={16} className="flex-shrink-0" />
                {!collapsed && <span>Leaderboard</span>}
              </a>
            </Link>
          )}
        </nav>

        {/* Collapse toggle */}
        <div className="px-2 pb-2">
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-md text-xs text-gray-400 hover:text-gray-600 hover:bg-gray-50 transition-colors"
            data-testid="sidebar-collapse-toggle"
          >
            {collapsed ? <ChevronRight size={14} /> : <><ChevronLeft size={14} /><span>Collapse</span></>}
          </button>
        </div>

        {/* User Footer */}
        <div className="border-t border-gray-100 p-3">
          <div className={`flex items-center ${collapsed ? "justify-center" : "gap-2"}`}>
            <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
              <span className="text-xs font-bold text-white">{currentUser.initials}</span>
            </div>
            {!collapsed && (
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-gray-900 truncate">{currentUser.name}</p>
                <p className="text-[10px] text-gray-400 truncate capitalize">{currentUser.role}</p>
              </div>
            )}
            {!collapsed && (
              <button
                onClick={handleLogout}
                className="p-1 rounded text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors"
                data-testid="button-logout"
                title="Logout"
              >
                <LogOut size={14} />
              </button>
            )}
          </div>
          {collapsed && (
            <button
              onClick={handleLogout}
              className="mt-2 w-full flex justify-center p-1 rounded text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors"
              data-testid="button-logout-collapsed"
            >
              <LogOut size={14} />
            </button>
          )}
        </div>
      </motion.aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        <header className="h-12 bg-white border-b border-gray-200 flex items-center px-6 gap-4 flex-shrink-0">
          <div className="flex-1">
            <nav className="flex items-center gap-1 text-sm text-gray-500">
              <TrendingUp size={14} className="text-gray-400" />
              <span className="mx-1 text-gray-300">/</span>
              <span className="capitalize font-medium text-gray-700">
                {location.split("/").filter(Boolean).join(" / ").replace(/([A-Z])/g, ' $1') || "Dashboard"}
              </span>
            </nav>
          </div>
          <div className="flex items-center gap-3">
            {currentUser.role !== "employee" && (
              <span className="text-xs text-white bg-blue-600 px-2 py-0.5 rounded-full font-medium capitalize">
                {currentUser.role === "manager" ? "Manager" : "Admin"}
              </span>
            )}
            <Link href="/employee/notifications">
              <a className="relative p-1.5 text-gray-400 hover:text-gray-600 transition-colors">
                <Bell size={16} />
                {unreadCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 bg-red-500 text-white text-[9px] font-bold rounded-full w-3.5 h-3.5 flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </a>
            </Link>
            <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center">
              <span className="text-[10px] font-bold text-white">{currentUser.initials}</span>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={location}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
