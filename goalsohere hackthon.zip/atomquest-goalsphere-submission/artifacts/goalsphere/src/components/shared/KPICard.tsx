import type { ReactNode } from "react";
import { motion } from "framer-motion";

interface KPICardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: ReactNode;
  iconBg?: string;
  trend?: { value: number; label: string };
  className?: string;
}

export function KPICard({ title, value, subtitle, icon, iconBg = "bg-blue-50", trend, className = "" }: KPICardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`bg-white rounded-lg border border-gray-200 shadow-sm p-5 ${className}`}
      data-testid="kpi-card"
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-sm font-medium text-gray-500">{title}</p>
          <p className="mt-1 text-2xl font-semibold text-gray-900" data-testid={`kpi-value-${title.replace(/\s+/g, "-").toLowerCase()}`}>{value}</p>
          {subtitle && <p className="mt-0.5 text-xs text-gray-400">{subtitle}</p>}
          {trend && (
            <div className={`mt-2 flex items-center gap-1 text-xs font-medium ${trend.value >= 0 ? "text-green-600" : "text-red-500"}`}>
              <span>{trend.value >= 0 ? "+" : ""}{trend.value}%</span>
              <span className="text-gray-400 font-normal">{trend.label}</span>
            </div>
          )}
        </div>
        <div className={`${iconBg} p-2.5 rounded-lg`}>
          {icon}
        </div>
      </div>
    </motion.div>
  );
}
