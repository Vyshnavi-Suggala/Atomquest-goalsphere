interface GoalProgressBarProps {
  progress: number;
  showLabel?: boolean;
  size?: "sm" | "md";
  className?: string;
}

export function GoalProgressBar({ progress, showLabel = true, size = "md", className = "" }: GoalProgressBarProps) {
  const pct = Math.min(100, Math.max(0, Math.round(progress)));
  const height = size === "sm" ? "h-1.5" : "h-2";
  const color = pct >= 80 ? "bg-green-500" : pct >= 50 ? "bg-blue-500" : pct >= 25 ? "bg-amber-500" : "bg-red-500";

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className={`flex-1 bg-gray-100 rounded-full ${height} overflow-hidden`}>
        <div
          className={`${height} ${color} rounded-full transition-all duration-500`}
          style={{ width: `${pct}%` }}
        />
      </div>
      {showLabel && <span className="text-xs font-medium text-gray-600 w-8 text-right">{pct}%</span>}
    </div>
  );
}
