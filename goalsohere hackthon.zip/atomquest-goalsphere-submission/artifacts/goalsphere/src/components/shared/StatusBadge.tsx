import type { GoalStatus, AchievementStatus, CycleStatus } from "@/data/mockData";

const goalStatusConfig: Record<GoalStatus, { label: string; className: string }> = {
  Draft:     { label: "Draft",     className: "bg-gray-100 text-gray-600 border-gray-200" },
  Submitted: { label: "Submitted", className: "bg-amber-50 text-amber-700 border-amber-200" },
  Approved:  { label: "Approved",  className: "bg-green-50 text-green-700 border-green-200" },
  Rejected:  { label: "Rejected",  className: "bg-red-50 text-red-700 border-red-200" },
  Rework:    { label: "Rework",    className: "bg-orange-50 text-orange-700 border-orange-200" },
  Locked:    { label: "Locked",    className: "bg-purple-50 text-purple-700 border-purple-200" },
};

const achievementStatusConfig: Record<AchievementStatus, { label: string; className: string }> = {
  NotStarted: { label: "Not Started", className: "bg-gray-100 text-gray-600 border-gray-200" },
  OnTrack:    { label: "On Track",    className: "bg-blue-50 text-blue-700 border-blue-200" },
  Completed:  { label: "Completed",   className: "bg-green-50 text-green-700 border-green-200" },
};

const cycleStatusConfig: Record<CycleStatus, { label: string; className: string }> = {
  Active:    { label: "Active",    className: "bg-green-50 text-green-700 border-green-200" },
  Closed:    { label: "Closed",    className: "bg-gray-100 text-gray-600 border-gray-200" },
  Upcoming:  { label: "Upcoming",  className: "bg-blue-50 text-blue-700 border-blue-200" },
};

export function GoalStatusBadge({ status }: { status: GoalStatus }) {
  const config = goalStatusConfig[status];
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${config.className}`}>
      {config.label}
    </span>
  );
}

export function AchievementStatusBadge({ status }: { status: AchievementStatus }) {
  const config = achievementStatusConfig[status];
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${config.className}`}>
      {config.label}
    </span>
  );
}

export function CycleStatusBadge({ status }: { status: CycleStatus }) {
  const config = cycleStatusConfig[status];
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${config.className}`}>
      {config.label}
    </span>
  );
}
