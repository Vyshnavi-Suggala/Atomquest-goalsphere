export type Role = "employee" | "manager" | "admin";
export type Department = "Engineering" | "Sales" | "Marketing" | "HR" | "Finance";
export type GoalStatus = "Draft" | "Submitted" | "Approved" | "Rejected" | "Rework" | "Locked";
export type UoM = "Numeric" | "Percentage" | "Timeline" | "ZeroBased";
export type AchievementStatus = "NotStarted" | "OnTrack" | "Completed";
export type CyclePhase = "GoalSetting" | "Q1Checkin" | "Q2Checkin" | "Q3Checkin" | "AnnualReview";
export type CycleStatus = "Active" | "Closed" | "Upcoming";
export type ThrustArea = "Customer Focus" | "Revenue Growth" | "Operational Excellence" | "People Development" | "Innovation";

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  department: Department;
  managerId: string | null;
  jobTitle: string;
  initials: string;
}

export interface Goal {
  id: string;
  employeeId: string;
  cycleId: string;
  thrustArea: ThrustArea;
  title: string;
  description: string;
  unitOfMeasurement: UoM;
  target: number;
  weightage: number;
  deadline: string;
  status: GoalStatus;
  isShared: boolean;
  sharedBy?: string;
  actualAchievement?: number;
  achievementStatus: AchievementStatus;
  remarks?: string;
  managerComments?: string;
  createdAt: string;
  updatedAt: string;
}

export interface GoalCycle {
  id: string;
  name: string;
  phase: CyclePhase;
  status: CycleStatus;
  startDate: string;
  endDate: string;
}

export interface Notification {
  id: string;
  userId: string;
  type: "approval" | "rejection" | "deadline" | "checkin" | "escalation" | "rework" | "unlock";
  message: string;
  read: boolean;
  createdAt: string;
  relatedGoalId?: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  action: string;
  entityType: "Goal" | "User" | "Cycle" | "Rating";
  entityId: string;
  details: string;
  timestamp: string;
}

export interface PerformanceRating {
  id: string;
  employeeId: string;
  managerId: string;
  cycleId: string;
  rating: number;
  comments: string;
  createdAt: string;
}

export const USERS: User[] = [
  { id: "u1", name: "Priya Sharma", email: "priya@atomquest.com", role: "admin", department: "HR", managerId: null, jobTitle: "HR Director", initials: "PS" },
  { id: "u2", name: "David Chen", email: "david@atomquest.com", role: "manager", department: "Engineering", managerId: "u1", jobTitle: "Engineering Manager", initials: "DC" },
  { id: "u3", name: "Rahul Kapoor", email: "rahul@atomquest.com", role: "manager", department: "Sales", managerId: "u1", jobTitle: "Sales Manager", initials: "RK" },
  { id: "u4", name: "Sarah Johnson", email: "sarah@atomquest.com", role: "employee", department: "Engineering", managerId: "u2", jobTitle: "Senior Software Engineer", initials: "SJ" },
  { id: "u5", name: "Michael Torres", email: "michael@atomquest.com", role: "employee", department: "Engineering", managerId: "u2", jobTitle: "Software Engineer", initials: "MT" },
  { id: "u6", name: "Aisha Patel", email: "aisha@atomquest.com", role: "employee", department: "Engineering", managerId: "u2", jobTitle: "QA Engineer", initials: "AP" },
  { id: "u7", name: "James Wilson", email: "james@atomquest.com", role: "employee", department: "Engineering", managerId: "u2", jobTitle: "DevOps Engineer", initials: "JW" },
  { id: "u8", name: "Meera Nair", email: "meera@atomquest.com", role: "employee", department: "Sales", managerId: "u3", jobTitle: "Account Executive", initials: "MN" },
  { id: "u9", name: "Carlos Rivera", email: "carlos@atomquest.com", role: "employee", department: "Sales", managerId: "u3", jobTitle: "Sales Representative", initials: "CR" },
  { id: "u10", name: "Lisa Zhang", email: "lisa@atomquest.com", role: "employee", department: "Marketing", managerId: "u1", jobTitle: "Marketing Specialist", initials: "LZ" },
];

export const CYCLES: GoalCycle[] = [
  { id: "cy1", name: "Q1 2025", phase: "AnnualReview", status: "Closed", startDate: "2025-01-01", endDate: "2025-03-31" },
  { id: "cy2", name: "Q2 2025", phase: "Q2Checkin", status: "Closed", startDate: "2025-04-01", endDate: "2025-06-30" },
  { id: "cy3", name: "Q3 2025", phase: "Q3Checkin", status: "Active", startDate: "2025-07-01", endDate: "2025-09-30" },
  { id: "cy4", name: "Q4 2025", phase: "GoalSetting", status: "Upcoming", startDate: "2025-10-01", endDate: "2025-12-31" },
];

export const GOALS: Goal[] = [
  // Sarah Johnson - Engineering (u4) - Cycle Q3 (cy3)
  { id: "g1", employeeId: "u4", cycleId: "cy3", thrustArea: "Innovation", title: "Migrate Legacy APIs to GraphQL", description: "Refactor 5 core REST endpoints to GraphQL for improved performance and developer experience.", unitOfMeasurement: "Numeric", target: 5, weightage: 25, deadline: "2025-09-15", status: "Approved", isShared: false, actualAchievement: 3, achievementStatus: "OnTrack", remarks: "Completed 3 out of 5 APIs. On track.", managerComments: "Good progress, keep it up.", createdAt: "2025-07-02", updatedAt: "2025-08-10" },
  { id: "g2", employeeId: "u4", cycleId: "cy3", thrustArea: "Operational Excellence", title: "Reduce System Downtime to <0.1%", description: "Implement HA architecture to achieve 99.9% uptime SLA for production systems.", unitOfMeasurement: "Percentage", target: 99.9, weightage: 20, deadline: "2025-09-30", status: "Approved", isShared: false, actualAchievement: 99.95, achievementStatus: "Completed", remarks: "Exceeded target.", createdAt: "2025-07-02", updatedAt: "2025-08-15" },
  { id: "g3", employeeId: "u4", cycleId: "cy3", thrustArea: "People Development", title: "Mentor 2 Junior Engineers", description: "Conduct weekly 1:1s and code reviews for 2 junior engineers, helping them level up.", unitOfMeasurement: "Numeric", target: 2, weightage: 15, deadline: "2025-09-30", status: "Approved", isShared: false, actualAchievement: 2, achievementStatus: "Completed", createdAt: "2025-07-02", updatedAt: "2025-08-01" },
  { id: "g4", employeeId: "u4", cycleId: "cy3", thrustArea: "Customer Focus", title: "Reduce API Response Time by 30%", description: "Optimize database queries and implement caching to reduce p95 latency by 30%.", unitOfMeasurement: "Percentage", target: 30, weightage: 20, deadline: "2025-09-20", status: "Submitted", isShared: false, actualAchievement: undefined, achievementStatus: "NotStarted", createdAt: "2025-07-05", updatedAt: "2025-07-20" },
  { id: "g5", employeeId: "u4", cycleId: "cy3", thrustArea: "Operational Excellence", title: "Complete CI/CD Pipeline Overhaul", description: "Implement GitHub Actions based CI/CD pipeline replacing Jenkins.", unitOfMeasurement: "Timeline", target: 100, weightage: 20, deadline: "2025-09-10", status: "Approved", isShared: false, actualAchievement: 100, achievementStatus: "Completed", createdAt: "2025-07-02", updatedAt: "2025-09-05" },

  // Michael Torres (u5) - Cycle Q3
  { id: "g6", employeeId: "u5", cycleId: "cy3", thrustArea: "Innovation", title: "Build Internal Component Library", description: "Create a shared React component library with 20+ reusable UI components.", unitOfMeasurement: "Numeric", target: 20, weightage: 30, deadline: "2025-09-30", status: "Approved", isShared: false, actualAchievement: 14, achievementStatus: "OnTrack", createdAt: "2025-07-03", updatedAt: "2025-08-20" },
  { id: "g7", employeeId: "u5", cycleId: "cy3", thrustArea: "Operational Excellence", title: "Achieve 80% Test Coverage", description: "Write unit and integration tests to bring overall coverage from 45% to 80%.", unitOfMeasurement: "Percentage", target: 80, weightage: 25, deadline: "2025-09-25", status: "Approved", isShared: false, actualAchievement: 72, achievementStatus: "OnTrack", createdAt: "2025-07-03", updatedAt: "2025-08-22" },
  { id: "g8", employeeId: "u5", cycleId: "cy3", thrustArea: "Customer Focus", title: "Fix 50 Customer-Reported Bugs", description: "Address and close 50 bugs reported from customer support tickets.", unitOfMeasurement: "Numeric", target: 50, weightage: 25, deadline: "2025-09-30", status: "Approved", isShared: false, actualAchievement: 38, achievementStatus: "OnTrack", createdAt: "2025-07-03", updatedAt: "2025-08-25" },
  { id: "g9", employeeId: "u5", cycleId: "cy3", thrustArea: "People Development", title: "Complete AWS Certification", description: "Pass AWS Solutions Architect Associate exam.", unitOfMeasurement: "ZeroBased", target: 0, weightage: 20, deadline: "2025-09-15", status: "Rework", isShared: false, actualAchievement: undefined, achievementStatus: "NotStarted", managerComments: "Please add more specific milestones and study plan.", createdAt: "2025-07-03", updatedAt: "2025-08-01" },

  // Aisha Patel (u6) - Cycle Q3
  { id: "g10", employeeId: "u6", cycleId: "cy3", thrustArea: "Operational Excellence", title: "Achieve Zero Critical Bugs in Production", description: "Establish rigorous QA process to prevent critical bugs from reaching production.", unitOfMeasurement: "ZeroBased", target: 0, weightage: 30, deadline: "2025-09-30", status: "Approved", isShared: false, actualAchievement: 0, achievementStatus: "Completed", createdAt: "2025-07-04", updatedAt: "2025-09-01" },
  { id: "g11", employeeId: "u6", cycleId: "cy3", thrustArea: "Innovation", title: "Implement Automated E2E Test Suite", description: "Build Playwright-based E2E test suite covering all critical user flows.", unitOfMeasurement: "Numeric", target: 100, weightage: 25, deadline: "2025-09-28", status: "Approved", isShared: false, actualAchievement: 65, achievementStatus: "OnTrack", createdAt: "2025-07-04", updatedAt: "2025-08-28" },
  { id: "g12", employeeId: "u6", cycleId: "cy3", thrustArea: "Operational Excellence", title: "Document QA Processes", description: "Create comprehensive QA runbooks and testing guidelines.", unitOfMeasurement: "Percentage", target: 100, weightage: 20, deadline: "2025-09-20", status: "Submitted", isShared: false, actualAchievement: undefined, achievementStatus: "NotStarted", createdAt: "2025-07-05", updatedAt: "2025-07-20" },
  { id: "g13", employeeId: "u6", cycleId: "cy3", thrustArea: "Customer Focus", title: "Reduce Bug Escape Rate by 40%", description: "Implement shift-left testing to reduce bugs found in production.", unitOfMeasurement: "Percentage", target: 40, weightage: 25, deadline: "2025-09-30", status: "Approved", isShared: false, actualAchievement: 35, achievementStatus: "OnTrack", createdAt: "2025-07-04", updatedAt: "2025-08-20" },

  // James Wilson (u7) - DevOps
  { id: "g14", employeeId: "u7", cycleId: "cy3", thrustArea: "Operational Excellence", title: "Implement Kubernetes Cluster Autoscaling", description: "Set up HPA and cluster autoscaler for production EKS cluster.", unitOfMeasurement: "Timeline", target: 100, weightage: 30, deadline: "2025-08-31", status: "Approved", isShared: false, actualAchievement: 100, achievementStatus: "Completed", createdAt: "2025-07-02", updatedAt: "2025-08-28" },
  { id: "g15", employeeId: "u7", cycleId: "cy3", thrustArea: "Operational Excellence", title: "Reduce Infrastructure Costs by 20%", description: "Optimize cloud resource usage and right-size instances.", unitOfMeasurement: "Percentage", target: 20, weightage: 25, deadline: "2025-09-30", status: "Approved", isShared: false, actualAchievement: 18, achievementStatus: "OnTrack", createdAt: "2025-07-02", updatedAt: "2025-08-25" },
  { id: "g16", employeeId: "u7", cycleId: "cy3", thrustArea: "Innovation", title: "Set Up Observability Platform", description: "Deploy Datadog with custom dashboards for all services.", unitOfMeasurement: "Numeric", target: 10, weightage: 25, deadline: "2025-09-15", status: "Draft", isShared: false, actualAchievement: undefined, achievementStatus: "NotStarted", createdAt: "2025-07-10", updatedAt: "2025-07-10" },
  { id: "g17", employeeId: "u7", cycleId: "cy3", thrustArea: "People Development", title: "Get HashiCorp Terraform Certification", description: "Complete Terraform Associate certification.", unitOfMeasurement: "ZeroBased", target: 0, weightage: 20, deadline: "2025-09-30", status: "Approved", isShared: false, actualAchievement: 0, achievementStatus: "Completed", createdAt: "2025-07-02", updatedAt: "2025-09-10" },

  // Meera Nair (u8) - Sales
  { id: "g18", employeeId: "u8", cycleId: "cy3", thrustArea: "Revenue Growth", title: "Achieve $500K in New ARR", description: "Close new enterprise accounts contributing $500K in annual recurring revenue.", unitOfMeasurement: "Numeric", target: 500000, weightage: 35, deadline: "2025-09-30", status: "Approved", isShared: false, actualAchievement: 380000, achievementStatus: "OnTrack", createdAt: "2025-07-01", updatedAt: "2025-08-30" },
  { id: "g19", employeeId: "u8", cycleId: "cy3", thrustArea: "Customer Focus", title: "Maintain 95% Customer Retention", description: "Ensure quarterly churn remains below 5% for existing accounts.", unitOfMeasurement: "Percentage", target: 95, weightage: 25, deadline: "2025-09-30", status: "Approved", isShared: false, actualAchievement: 96.5, achievementStatus: "Completed", createdAt: "2025-07-01", updatedAt: "2025-09-05" },
  { id: "g20", employeeId: "u8", cycleId: "cy3", thrustArea: "Operational Excellence", title: "Close 15 New Deals", description: "Sign 15 new customer contracts across SMB and enterprise segments.", unitOfMeasurement: "Numeric", target: 15, weightage: 25, deadline: "2025-09-30", status: "Submitted", isShared: false, actualAchievement: undefined, achievementStatus: "NotStarted", createdAt: "2025-07-03", updatedAt: "2025-07-25" },
  { id: "g21", employeeId: "u8", cycleId: "cy3", thrustArea: "People Development", title: "Complete Sandler Sales Training", description: "Finish the Sandler methodology certification program.", unitOfMeasurement: "ZeroBased", target: 0, weightage: 15, deadline: "2025-08-31", status: "Approved", isShared: false, actualAchievement: 0, achievementStatus: "Completed", createdAt: "2025-07-01", updatedAt: "2025-08-28" },

  // Carlos Rivera (u9) - Sales
  { id: "g22", employeeId: "u9", cycleId: "cy3", thrustArea: "Revenue Growth", title: "Generate $200K in Pipeline", description: "Build and maintain a healthy sales pipeline of $200K+ in qualified opportunities.", unitOfMeasurement: "Numeric", target: 200000, weightage: 30, deadline: "2025-09-30", status: "Approved", isShared: false, actualAchievement: 145000, achievementStatus: "OnTrack", createdAt: "2025-07-02", updatedAt: "2025-08-20" },
  { id: "g23", employeeId: "u9", cycleId: "cy3", thrustArea: "Customer Focus", title: "Conduct 60 Discovery Calls", description: "Have meaningful discovery conversations with 60 prospective customers.", unitOfMeasurement: "Numeric", target: 60, weightage: 25, deadline: "2025-09-30", status: "Rejected", isShared: false, actualAchievement: undefined, achievementStatus: "NotStarted", managerComments: "Target seems too low. Please revise to 80 discovery calls.", createdAt: "2025-07-02", updatedAt: "2025-07-28" },
  { id: "g24", employeeId: "u9", cycleId: "cy3", thrustArea: "Operational Excellence", title: "Maintain CRM Data Quality at 90%+", description: "Keep all Salesforce records updated and accurate above 90% quality score.", unitOfMeasurement: "Percentage", target: 90, weightage: 25, deadline: "2025-09-30", status: "Approved", isShared: false, actualAchievement: 93, achievementStatus: "Completed", createdAt: "2025-07-02", updatedAt: "2025-09-01" },
  { id: "g25", employeeId: "u9", cycleId: "cy3", thrustArea: "Innovation", title: "Implement Sales Automation Workflow", description: "Set up automated follow-up sequences in HubSpot saving 5hrs/week.", unitOfMeasurement: "Numeric", target: 5, weightage: 20, deadline: "2025-09-30", status: "Draft", isShared: false, actualAchievement: undefined, achievementStatus: "NotStarted", createdAt: "2025-07-10", updatedAt: "2025-07-10" },

  // Lisa Zhang (u10) - Marketing  
  { id: "g26", employeeId: "u10", cycleId: "cy3", thrustArea: "Revenue Growth", title: "Generate 500 MQLs", description: "Drive 500 Marketing Qualified Leads through campaigns and content.", unitOfMeasurement: "Numeric", target: 500, weightage: 30, deadline: "2025-09-30", status: "Approved", isShared: false, actualAchievement: 420, achievementStatus: "OnTrack", createdAt: "2025-07-01", updatedAt: "2025-08-28" },
  { id: "g27", employeeId: "u10", cycleId: "cy3", thrustArea: "Customer Focus", title: "Increase Website Traffic by 40%", description: "Grow organic and paid traffic by 40% QoQ through SEO and campaigns.", unitOfMeasurement: "Percentage", target: 40, weightage: 25, deadline: "2025-09-30", status: "Approved", isShared: false, actualAchievement: 38, achievementStatus: "OnTrack", createdAt: "2025-07-01", updatedAt: "2025-09-01" },
  { id: "g28", employeeId: "u10", cycleId: "cy3", thrustArea: "Innovation", title: "Launch ABM Campaign for Enterprise", description: "Execute account-based marketing program targeting 20 enterprise accounts.", unitOfMeasurement: "Numeric", target: 20, weightage: 25, deadline: "2025-09-20", status: "Submitted", isShared: false, actualAchievement: undefined, achievementStatus: "NotStarted", createdAt: "2025-07-03", updatedAt: "2025-07-25" },
  { id: "g29", employeeId: "u10", cycleId: "cy3", thrustArea: "People Development", title: "Complete Google Analytics 4 Certification", description: "Become GA4 certified to improve data-driven marketing decisions.", unitOfMeasurement: "ZeroBased", target: 0, weightage: 20, deadline: "2025-08-31", status: "Approved", isShared: false, actualAchievement: 0, achievementStatus: "Completed", createdAt: "2025-07-01", updatedAt: "2025-08-25" },
];

export const NOTIFICATIONS: Notification[] = [
  { id: "n1", userId: "u4", type: "approval", message: "Your goal 'Migrate Legacy APIs to GraphQL' has been approved by David Chen.", read: false, createdAt: "2025-08-10", relatedGoalId: "g1" },
  { id: "n2", userId: "u4", type: "approval", message: "Your goal 'Reduce System Downtime to <0.1%' has been approved.", read: false, createdAt: "2025-08-12", relatedGoalId: "g2" },
  { id: "n3", userId: "u4", type: "deadline", message: "Deadline reminder: 'Reduce API Response Time by 30%' is due in 10 days.", read: true, createdAt: "2025-09-10", relatedGoalId: "g4" },
  { id: "n4", userId: "u4", type: "checkin", message: "Q3 Check-in is now open. Please update your progress for all goals.", read: false, createdAt: "2025-08-01" },
  { id: "n5", userId: "u5", type: "rework", message: "Your goal 'Complete AWS Certification' has been returned for rework. Please review manager comments.", read: false, createdAt: "2025-08-01", relatedGoalId: "g9" },
  { id: "n6", userId: "u5", type: "approval", message: "Your goals have been reviewed. Check your goal list for status updates.", read: true, createdAt: "2025-08-05" },
  { id: "n7", userId: "u9", type: "rejection", message: "Your goal 'Conduct 60 Discovery Calls' was rejected. Please revise and resubmit.", read: false, createdAt: "2025-07-28", relatedGoalId: "g23" },
  { id: "n8", userId: "u2", type: "approval", message: "Michael Torres submitted a revised goal for your review.", read: false, createdAt: "2025-08-02" },
  { id: "n9", userId: "u2", type: "escalation", message: "Escalation: Sarah Johnson's Q3 goals require approval — pending for 8 days.", read: false, createdAt: "2025-09-05" },
  { id: "n10", userId: "u6", type: "approval", message: "Your goal 'Achieve Zero Critical Bugs in Production' has been approved.", read: true, createdAt: "2025-08-05", relatedGoalId: "g10" },
  { id: "n11", userId: "u7", type: "approval", message: "Your goal 'Implement Kubernetes Cluster Autoscaling' has been approved.", read: true, createdAt: "2025-08-03", relatedGoalId: "g14" },
  { id: "n12", userId: "u8", type: "checkin", message: "Q3 Check-in window is open. Please submit your actual achievement data.", read: false, createdAt: "2025-08-01" },
  { id: "n13", userId: "u10", type: "deadline", message: "Reminder: 'Launch ABM Campaign for Enterprise' deadline is approaching.", read: false, createdAt: "2025-09-12", relatedGoalId: "g28" },
  { id: "n14", userId: "u3", type: "approval", message: "Meera Nair submitted 3 goals for your review.", read: false, createdAt: "2025-07-25" },
];

export const AUDIT_LOGS: AuditLog[] = [
  { id: "al1", userId: "u2", action: "Goal Approved", entityType: "Goal", entityId: "g1", details: "Approved goal 'Migrate Legacy APIs to GraphQL' for Sarah Johnson", timestamp: "2025-08-10T09:30:00" },
  { id: "al2", userId: "u2", action: "Goal Approved", entityType: "Goal", entityId: "g2", details: "Approved goal 'Reduce System Downtime to <0.1%' for Sarah Johnson", timestamp: "2025-08-12T11:15:00" },
  { id: "al3", userId: "u2", action: "Goal Rejected", entityType: "Goal", entityId: "g9", details: "Returned goal 'Complete AWS Certification' for rework — Michael Torres", timestamp: "2025-08-01T14:20:00" },
  { id: "al4", userId: "u3", action: "Goal Rejected", entityType: "Goal", entityId: "g23", details: "Rejected goal 'Conduct 60 Discovery Calls' for Carlos Rivera — target too low", timestamp: "2025-07-28T10:00:00" },
  { id: "al5", userId: "u4", action: "Goal Submitted", entityType: "Goal", entityId: "g4", details: "Sarah Johnson submitted goal 'Reduce API Response Time by 30%'", timestamp: "2025-07-20T08:45:00" },
  { id: "al6", userId: "u2", action: "Goal Approved", entityType: "Goal", entityId: "g6", details: "Approved goal 'Build Internal Component Library' for Michael Torres", timestamp: "2025-08-05T10:00:00" },
  { id: "al7", userId: "u1", action: "Cycle Updated", entityType: "Cycle", entityId: "cy3", details: "Admin Priya Sharma changed Q3 2025 cycle phase to Q3 Check-in", timestamp: "2025-08-01T09:00:00" },
  { id: "al8", userId: "u1", action: "Cycle Closed", entityType: "Cycle", entityId: "cy1", details: "Admin closed Q1 2025 cycle", timestamp: "2025-04-01T08:00:00" },
  { id: "al9", userId: "u4", action: "Check-in Updated", entityType: "Goal", entityId: "g1", details: "Sarah Johnson updated Q3 check-in: 3/5 APIs completed", timestamp: "2025-08-10T16:30:00" },
  { id: "al10", userId: "u8", action: "Goal Submitted", entityType: "Goal", entityId: "g20", details: "Meera Nair submitted 'Close 15 New Deals'", timestamp: "2025-07-25T09:00:00" },
  { id: "al11", userId: "u2", action: "Goal Approved", entityType: "Goal", entityId: "g14", details: "Approved DevOps goals for James Wilson", timestamp: "2025-08-03T11:00:00" },
  { id: "al12", userId: "u5", action: "Goal Created", entityType: "Goal", entityId: "g6", details: "Michael Torres created 'Build Internal Component Library'", timestamp: "2025-07-03T10:00:00" },
  { id: "al13", userId: "u1", action: "Goal Unlocked", entityType: "Goal", entityId: "g5", details: "Admin unlocked goal for editing — requested by employee", timestamp: "2025-08-20T14:00:00" },
];

export const PERFORMANCE_RATINGS: PerformanceRating[] = [
  { id: "pr1", employeeId: "u4", managerId: "u2", cycleId: "cy1", rating: 5, comments: "Exceptional performance. Sarah delivered all goals above expectations and showed great leadership.", createdAt: "2025-04-05" },
  { id: "pr2", employeeId: "u5", managerId: "u2", cycleId: "cy1", rating: 4, comments: "Solid performance. Michael consistently delivered quality work with some areas for improvement in test coverage.", createdAt: "2025-04-05" },
  { id: "pr3", employeeId: "u6", managerId: "u2", cycleId: "cy1", rating: 4, comments: "Aisha did great work on QA processes. Bug rates dropped significantly under her leadership.", createdAt: "2025-04-05" },
  { id: "pr4", employeeId: "u7", managerId: "u2", cycleId: "cy1", rating: 3, comments: "James met expectations. Infrastructure costs need more attention next quarter.", createdAt: "2025-04-05" },
  { id: "pr5", employeeId: "u8", managerId: "u3", cycleId: "cy1", rating: 5, comments: "Meera exceeded sales targets by 20%. Outstanding customer relationships and deal closures.", createdAt: "2025-04-05" },
  { id: "pr6", employeeId: "u9", managerId: "u3", cycleId: "cy1", rating: 3, comments: "Carlos is improving. Pipeline generation needs to scale in Q2.", createdAt: "2025-04-05" },
  { id: "pr7", employeeId: "u10", managerId: "u1", cycleId: "cy1", rating: 4, comments: "Lisa drove strong MQL numbers and exceeded website traffic goals.", createdAt: "2025-04-05" },
];

export function seedLocalStorage(): void {
  const seeded = localStorage.getItem("aq_seeded_v3");
  if (!seeded) {
    localStorage.setItem("aq_users", JSON.stringify(USERS));
    localStorage.setItem("aq_goals", JSON.stringify(GOALS));
    localStorage.setItem("aq_cycles", JSON.stringify(CYCLES));
    localStorage.setItem("aq_notifications", JSON.stringify(NOTIFICATIONS));
    localStorage.setItem("aq_audit_logs", JSON.stringify(AUDIT_LOGS));
    localStorage.setItem("aq_ratings", JSON.stringify(PERFORMANCE_RATINGS));
    localStorage.setItem("aq_seeded_v3", "true");
  }
}
