import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Target, Shield, Users, User, ChevronRight, CheckCircle } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useData } from "@/contexts/DataContext";
import type { User as UserType } from "@/data/mockData";

const demoProfiles = [
  {
    userId: "u4",
    role: "Employee" as const,
    label: "Sarah Johnson",
    title: "Senior Software Engineer",
    dept: "Engineering",
    icon: User,
    color: "border-blue-200 hover:border-blue-400 hover:bg-blue-50",
    iconBg: "bg-blue-100 text-blue-600",
    description: "View goals, submit check-ins, track progress",
  },
  {
    userId: "u2",
    role: "Manager" as const,
    label: "David Chen",
    title: "Engineering Manager",
    dept: "Engineering",
    icon: Users,
    color: "border-indigo-200 hover:border-indigo-400 hover:bg-indigo-50",
    iconBg: "bg-indigo-100 text-indigo-600",
    description: "Approve goals, review team performance, manage check-ins",
  },
  {
    userId: "u1",
    role: "Admin/HR" as const,
    label: "Priya Sharma",
    title: "HR Director",
    dept: "Human Resources",
    icon: Shield,
    color: "border-purple-200 hover:border-purple-400 hover:bg-purple-50",
    iconBg: "bg-purple-100 text-purple-600",
    description: "Full access: analytics, cycles, user management, reports",
  },
];

export default function Login() {
  const { login } = useAuth();
  const { users } = useData();
  const [, navigate] = useLocation();
  const [loading, setLoading] = useState<string | null>(null);

  const handleLogin = (userId: string, roleKey: string) => {
    setLoading(userId);
    const user = users.find(u => u.id === userId);
    if (!user) return;
    setTimeout(() => {
      login(user);
      if (user.role === "admin") navigate("/admin/dashboard");
      else if (user.role === "manager") navigate("/manager/dashboard");
      else navigate("/employee/dashboard");
    }, 600);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="text-center mb-10"
        >
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-blue-600 shadow-lg mb-4">
            <Target size={28} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">GoalSphere</h1>
          <p className="text-gray-500 mt-1 text-sm">AtomQuest Enterprise Performance Management Portal</p>
          <div className="flex items-center justify-center gap-4 mt-3">
            {["OKR Tracking", "Performance Reviews", "Team Analytics"].map(f => (
              <span key={f} className="flex items-center gap-1 text-xs text-gray-500">
                <CheckCircle size={12} className="text-green-500" />
                {f}
              </span>
            ))}
          </div>
        </motion.div>

        {/* Demo Login Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          <p className="text-center text-sm font-medium text-gray-500 mb-4 uppercase tracking-wide">Select your demo role to continue</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {demoProfiles.map((profile, i) => {
              const Icon = profile.icon;
              const isLoading = loading === profile.userId;
              return (
                <motion.button
                  key={profile.userId}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.15 + i * 0.05 }}
                  onClick={() => handleLogin(profile.userId, profile.role)}
                  disabled={!!loading}
                  data-testid={`login-card-${profile.role.toLowerCase().replace("/", "-")}`}
                  className={`relative text-left bg-white rounded-xl border-2 p-5 transition-all duration-200 cursor-pointer shadow-sm ${profile.color} ${loading ? "opacity-60" : ""}`}
                >
                  <div className={`inline-flex p-2.5 rounded-lg mb-3 ${profile.iconBg}`}>
                    <Icon size={20} />
                  </div>
                  <div className="mb-2">
                    <p className="text-xs font-semibold uppercase tracking-wide text-gray-400">{profile.role}</p>
                    <p className="text-lg font-bold text-gray-900">{profile.label}</p>
                    <p className="text-sm text-gray-500">{profile.title}</p>
                    <p className="text-xs text-gray-400">{profile.dept}</p>
                  </div>
                  <p className="text-xs text-gray-500 border-t border-gray-100 pt-3 mt-3">{profile.description}</p>
                  <div className="mt-4 flex items-center justify-between">
                    <span className="text-xs font-medium text-blue-600">{isLoading ? "Signing in..." : "Click to sign in"}</span>
                    <ChevronRight size={14} className="text-gray-400" />
                  </div>
                  {isLoading && (
                    <div className="absolute inset-0 bg-white/70 rounded-xl flex items-center justify-center">
                      <div className="w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
                    </div>
                  )}
                </motion.button>
              );
            })}
          </div>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center text-xs text-gray-400 mt-8"
        >
          AtomQuest GoalSphere — AtomQuest Hackathon Demo &bull; All data is simulated
        </motion.p>
      </div>
    </div>
  );
}
