import { useMemo } from "react";
import { motion } from "framer-motion";
import { Award, Star, TrendingUp } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useData } from "@/contexts/DataContext";
import { calculateOverallProgress } from "@/lib/progress";
import { GoalProgressBar } from "@/components/shared/GoalProgressBar";
import { PageHeader } from "@/components/shared/PageHeader";

const MEDALS = ["#F59E0B", "#9CA3AF", "#92400E"];

export default function Leaderboard() {
  const { users, goals, cycles, ratings } = useData();

  const employees = users.filter(u => u.role === "employee");
  const activeCycle = cycles.find(c => c.status === "Active");
  const cycleGoals = goals.filter(g => g.cycleId === (activeCycle?.id ?? "cy3"));

  const ranked = useMemo(() =>
    employees
      .map(u => {
        const empGoals = cycleGoals.filter(g => g.employeeId === u.id);
        const progress = calculateOverallProgress(empGoals);
        const latestRating = ratings.filter(r => r.employeeId === u.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
        const manager = users.find(m => m.id === u.managerId);
        return { user: u, progress, rating: latestRating?.rating ?? 0, ratingComment: latestRating?.comments, manager, goals: empGoals.length, approvedGoals: empGoals.filter(g => g.status === "Approved" || g.status === "Locked").length };
      })
      .sort((a, b) => b.progress - a.progress || b.rating - a.rating),
    [employees, cycleGoals, ratings, users]
  );

  const depts = Array.from(new Set(employees.map(u => u.department)));
  const deptRanking = useMemo(() => depts.map(dept => {
    const deptUsers = employees.filter(u => u.department === dept);
    const avg = deptUsers.length > 0
      ? Math.round(deptUsers.reduce((s, u) => s + calculateOverallProgress(cycleGoals.filter(g => g.employeeId === u.id)), 0) / deptUsers.length)
      : 0;
    return { dept, avg, members: deptUsers.length };
  }).sort((a, b) => b.avg - a.avg), [depts, employees, cycleGoals]);

  const ratingDist = useMemo(() => {
    const dist: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    ratings.forEach(r => { if (dist[r.rating] !== undefined) dist[r.rating]++; });
    return Object.entries(dist).map(([rating, count]) => ({ rating: `${rating} Star`, count }));
  }, [ratings]);

  return (
    <div data-testid="leaderboard">
      <PageHeader title="Performance Leaderboard" subtitle={`${activeCycle?.name} — Top performers`} />

      {/* Top 3 Podium */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        {ranked.slice(0, 3).map(({ user, progress, rating }, i) => (
          <motion.div
            key={user.id}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className={`bg-white rounded-xl border-2 shadow-sm p-5 text-center relative overflow-hidden ${i === 0 ? "border-amber-300" : i === 1 ? "border-gray-300" : "border-amber-700/30"}`}
            data-testid={`top-performer-${i + 1}`}
          >
            {i === 0 && <div className="absolute top-0 left-0 right-0 h-1 bg-amber-400" />}
            <div className="flex justify-center mb-3">
              <div className="relative">
                <div className="w-14 h-14 rounded-full bg-blue-600 flex items-center justify-center">
                  <span className="text-lg font-bold text-white">{user.initials}</span>
                </div>
                <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold text-white" style={{ backgroundColor: MEDALS[i] }}>
                  {i + 1}
                </div>
              </div>
            </div>
            <p className="font-bold text-gray-900">{user.name}</p>
            <p className="text-xs text-gray-500">{user.jobTitle}</p>
            <p className="text-xs text-gray-400 mt-0.5">{user.department}</p>
            <div className="mt-3">
              <p className="text-2xl font-bold text-blue-600">{progress}%</p>
              <p className="text-xs text-gray-400">Overall Progress</p>
            </div>
            {rating > 0 && (
              <div className="mt-2 flex items-center justify-center gap-1">
                {Array.from({ length: 5 }, (_, s) => (
                  <Star key={s} size={12} className={s < rating ? "text-amber-400 fill-amber-400" : "text-gray-200"} />
                ))}
              </div>
            )}
            <GoalProgressBar progress={progress} showLabel={false} className="mt-2" />
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Department Ranking */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2"><TrendingUp size={14} />Department Ranking</h3>
          <div className="space-y-3">
            {deptRanking.map((d, i) => (
              <div key={d.dept} className="flex items-center gap-3" data-testid={`dept-rank-${d.dept}`}>
                <span className="text-sm font-bold w-5 text-gray-400">#{i + 1}</span>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-xs font-medium text-gray-800">{d.dept}</p>
                    <span className="text-xs font-bold text-blue-600">{d.avg}%</span>
                  </div>
                  <GoalProgressBar progress={d.avg} showLabel={false} size="sm" />
                </div>
                <span className="text-[10px] text-gray-400">{d.members} members</span>
              </div>
            ))}
          </div>
        </div>

        {/* Rating Distribution */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2"><Star size={14} className="text-amber-500" />Performance Rating Distribution</h3>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={ratingDist}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="rating" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="#f59e0b" radius={[4, 4, 0, 0]} name="Employees" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Full Ranking Table */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100">
          <h3 className="text-sm font-semibold text-gray-700">Full Rankings</h3>
        </div>
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              {["Rank", "Employee", "Department", "Goals", "Approved", "Progress", "Rating"].map(h => (
                <th key={h} className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {ranked.map(({ user, progress, rating, goals: goalCount, approvedGoals }, i) => (
              <motion.tr key={user.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.02 }} className="hover:bg-gray-50" data-testid={`rank-row-${user.id}`}>
                <td className="px-4 py-3">
                  <span className="text-sm font-bold" style={{ color: i < 3 ? MEDALS[i] : "#6b7280" }}>#{i + 1}</span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
                      <span className="text-[10px] font-bold text-white">{user.initials}</span>
                    </div>
                    <div>
                      <p className="text-xs font-medium text-gray-900">{user.name}</p>
                      <p className="text-[10px] text-gray-400">{user.jobTitle}</p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 text-xs text-gray-500">{user.department}</td>
                <td className="px-4 py-3 text-xs text-gray-700">{goalCount}</td>
                <td className="px-4 py-3 text-xs text-gray-700">{approvedGoals}</td>
                <td className="px-4 py-3 w-36"><GoalProgressBar progress={progress} size="sm" /></td>
                <td className="px-4 py-3">
                  {rating > 0 ? (
                    <div className="flex items-center gap-0.5">
                      {Array.from({ length: 5 }, (_, s) => (
                        <Star key={s} size={11} className={s < rating ? "text-amber-400 fill-amber-400" : "text-gray-200"} />
                      ))}
                    </div>
                  ) : <span className="text-xs text-gray-400">—</span>}
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
