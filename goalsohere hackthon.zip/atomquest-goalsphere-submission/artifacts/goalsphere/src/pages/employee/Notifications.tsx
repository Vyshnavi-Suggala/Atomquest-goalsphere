import { useState } from "react";
import { motion } from "framer-motion";
import { Bell, CheckCheck, CheckCircle, XCircle, Clock, AlertTriangle, RefreshCw, Unlock } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useData } from "@/contexts/DataContext";
import { PageHeader } from "@/components/shared/PageHeader";

const typeConfig = {
  approval: { icon: CheckCircle, color: "text-green-500", bg: "bg-green-50" },
  rejection: { icon: XCircle, color: "text-red-500", bg: "bg-red-50" },
  deadline: { icon: Clock, color: "text-amber-500", bg: "bg-amber-50" },
  checkin: { icon: RefreshCw, color: "text-blue-500", bg: "bg-blue-50" },
  escalation: { icon: AlertTriangle, color: "text-orange-500", bg: "bg-orange-50" },
  rework: { icon: RefreshCw, color: "text-orange-500", bg: "bg-orange-50" },
  unlock: { icon: Unlock, color: "text-purple-500", bg: "bg-purple-50" },
};

export default function Notifications() {
  const { currentUser } = useAuth();
  const { notifications, markNotificationRead, markAllNotificationsRead } = useData();
  const [filter, setFilter] = useState<string>("All");

  const myNotifications = notifications
    .filter(n => n.userId === currentUser?.id)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  const filtered = filter === "All" ? myNotifications : filter === "Unread" ? myNotifications.filter(n => !n.read) : myNotifications.filter(n => n.type === filter);
  const unreadCount = myNotifications.filter(n => !n.read).length;

  return (
    <div data-testid="notifications-page">
      <PageHeader
        title="Notifications"
        subtitle={`${unreadCount} unread notification${unreadCount !== 1 ? "s" : ""}`}
        actions={
          unreadCount > 0 ? (
            <button
              onClick={() => markAllNotificationsRead(currentUser!.id)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-gray-300 text-gray-600 text-sm font-medium rounded-lg hover:bg-gray-50 transition-colors"
              data-testid="button-mark-all-read"
            >
              <CheckCheck size={14} />
              Mark all read
            </button>
          ) : undefined
        }
      />

      {/* Filter tabs */}
      <div className="flex gap-1 mb-4 bg-gray-100 p-1 rounded-lg w-fit">
        {["All", "Unread", "approval", "rejection", "deadline", "checkin", "escalation"].map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors capitalize ${filter === f ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}
            data-testid={`filter-notif-${f}`}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="space-y-2">
        {filtered.length === 0 ? (
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-12 text-center text-gray-400">
            <Bell size={32} className="mx-auto mb-3 opacity-40" />
            <p className="text-sm">No notifications found</p>
          </div>
        ) : filtered.map((n, idx) => {
          const config = typeConfig[n.type] ?? typeConfig.approval;
          const Icon = config.icon;
          return (
            <motion.div
              key={n.id}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.03 }}
              className={`flex items-start gap-3 p-4 rounded-lg border transition-colors cursor-pointer ${n.read ? "bg-white border-gray-200" : "bg-blue-50/50 border-blue-200"}`}
              onClick={() => !n.read && markNotificationRead(n.id)}
              data-testid={`notification-item-${n.id}`}
            >
              <div className={`p-2 rounded-lg ${config.bg} flex-shrink-0`}>
                <Icon size={16} className={config.color} />
              </div>
              <div className="flex-1 min-w-0">
                <p className={`text-sm ${n.read ? "text-gray-600" : "text-gray-900 font-medium"}`}>{n.message}</p>
                <p className="text-xs text-gray-400 mt-1">{new Date(n.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</p>
              </div>
              {!n.read && <div className="w-2 h-2 bg-blue-600 rounded-full mt-1.5 flex-shrink-0" />}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
