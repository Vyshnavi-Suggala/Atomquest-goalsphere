import { useState, useMemo } from "react";
import { useLocation, useParams } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ChevronLeft, AlertCircle, CheckCircle } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useData } from "@/contexts/DataContext";
import { getTotalWeightage } from "@/lib/progress";
import { PageHeader } from "@/components/shared/PageHeader";
import type { ThrustArea, UoM, Goal } from "@/data/mockData";

const THRUST_AREAS: ThrustArea[] = ["Customer Focus", "Revenue Growth", "Operational Excellence", "People Development", "Innovation"];
const UOM_OPTIONS: UoM[] = ["Numeric", "Percentage", "Timeline", "ZeroBased"];
const UOM_DESCRIPTIONS: Record<UoM, string> = {
  Numeric: "Progress = Achievement / Target",
  Percentage: "Progress = Target / Achievement",
  Timeline: "Based on completion date vs deadline",
  ZeroBased: "100% if value = 0, else 0%",
};

const schema = z.object({
  thrustArea: z.enum(["Customer Focus", "Revenue Growth", "Operational Excellence", "People Development", "Innovation"]),
  title: z.string().min(5, "Title must be at least 5 characters").max(120),
  description: z.string().min(10, "Description must be at least 10 characters"),
  unitOfMeasurement: z.enum(["Numeric", "Percentage", "Timeline", "ZeroBased"]),
  target: z.coerce.number().min(0, "Target must be >= 0"),
  weightage: z.coerce.number().min(10, "Minimum 10%").max(100, "Maximum 100%"),
  deadline: z.string().min(1, "Deadline is required"),
});

type FormValues = z.infer<typeof schema>;

export default function GoalForm() {
  const { currentUser } = useAuth();
  const { goals, cycles, addGoal, updateGoal, addAuditLog } = useData();
  const [, navigate] = useLocation();
  const params = useParams<{ id?: string }>();
  const isEdit = !!params.id;

  const activeCycle = cycles.find(c => c.status === "Active") ?? cycles[0];
  const existingGoal = isEdit ? goals.find(g => g.id === params.id) : null;

  const myGoals = useMemo(() =>
    goals.filter(g => g.employeeId === currentUser?.id && g.cycleId === activeCycle?.id),
    [goals, currentUser, activeCycle]
  );

  const { register, handleSubmit, watch, formState: { errors } } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: existingGoal ? {
      thrustArea: existingGoal.thrustArea,
      title: existingGoal.title,
      description: existingGoal.description,
      unitOfMeasurement: existingGoal.unitOfMeasurement,
      target: existingGoal.target,
      weightage: existingGoal.weightage,
      deadline: existingGoal.deadline,
    } : {
      thrustArea: "Customer Focus",
      unitOfMeasurement: "Numeric",
      weightage: 10,
      target: 100,
    },
  });

  const watchedWeightage = watch("weightage") ?? 0;
  const watchedUoM = watch("unitOfMeasurement");
  const otherGoalsWeightage = getTotalWeightage(myGoals.filter(g => g.id !== existingGoal?.id));
  const projectedTotal = otherGoalsWeightage + Number(watchedWeightage || 0);
  const canAddMore = myGoals.length < 8 || isEdit;

  const onSave = (data: FormValues, submit: boolean) => {
    if (!canAddMore && !isEdit) return;

    const now = new Date().toISOString().split("T")[0];
    if (isEdit && existingGoal) {
      updateGoal(existingGoal.id, { ...data, status: submit ? "Submitted" : existingGoal.status, updatedAt: now });
      addAuditLog({ id: `al-${Date.now()}`, userId: currentUser!.id, action: isEdit ? "Goal Updated" : "Goal Created", entityType: "Goal", entityId: existingGoal.id, details: `${currentUser!.name} ${isEdit ? "updated" : "created"} goal: ${data.title}`, timestamp: new Date().toISOString() });
    } else {
      const newGoal: Goal = {
        id: `g-${Date.now()}`,
        employeeId: currentUser!.id,
        cycleId: activeCycle!.id,
        ...data,
        status: submit ? "Submitted" : "Draft",
        isShared: false,
        achievementStatus: "NotStarted",
        createdAt: now,
        updatedAt: now,
      };
      addGoal(newGoal);
      addAuditLog({ id: `al-${Date.now()}`, userId: currentUser!.id, action: "Goal Created", entityType: "Goal", entityId: newGoal.id, details: `${currentUser!.name} created goal: ${data.title}`, timestamp: new Date().toISOString() });
    }
    navigate("/employee/goals");
  };

  return (
    <div data-testid="goal-form">
      <div className="mb-6">
        <button onClick={() => navigate("/employee/goals")} className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700 mb-4" data-testid="button-back">
          <ChevronLeft size={16} />
          Back to Goals
        </button>
        <PageHeader
          title={isEdit ? "Edit Goal" : "Create New Goal"}
          subtitle={`${activeCycle?.name} · ${myGoals.length}/8 goals`}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Form */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
            <form onSubmit={handleSubmit(d => onSave(d, false))} className="space-y-5">

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Thrust Area <span className="text-red-500">*</span></label>
                  <select {...register("thrustArea")} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent" data-testid="select-thrust-area">
                    {THRUST_AREAS.map(a => <option key={a} value={a}>{a}</option>)}
                  </select>
                  {errors.thrustArea && <p className="text-xs text-red-500 mt-1">{errors.thrustArea.message}</p>}
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Unit of Measurement <span className="text-red-500">*</span></label>
                  <select {...register("unitOfMeasurement")} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent" data-testid="select-uom">
                    {UOM_OPTIONS.map(u => <option key={u} value={u}>{u}</option>)}
                  </select>
                  {watchedUoM && <p className="text-[11px] text-gray-400 mt-1">{UOM_DESCRIPTIONS[watchedUoM]}</p>}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Goal Title <span className="text-red-500">*</span></label>
                <input {...register("title")} type="text" placeholder="e.g. Increase quarterly revenue by 20%" className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent" data-testid="input-goal-title" />
                {errors.title && <p className="text-xs text-red-500 mt-1">{errors.title.message}</p>}
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Goal Description <span className="text-red-500">*</span></label>
                <textarea {...register("description")} rows={3} placeholder="Describe what success looks like and how you plan to achieve this goal..." className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none" data-testid="textarea-description" />
                {errors.description && <p className="text-xs text-red-500 mt-1">{errors.description.message}</p>}
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Target <span className="text-red-500">*</span></label>
                  <input {...register("target")} type="number" min="0" className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500" data-testid="input-target" />
                  {errors.target && <p className="text-xs text-red-500 mt-1">{errors.target.message}</p>}
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Weightage (%) <span className="text-red-500">*</span></label>
                  <input {...register("weightage")} type="number" min="10" max="100" className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500" data-testid="input-weightage" />
                  {errors.weightage && <p className="text-xs text-red-500 mt-1">{errors.weightage.message}</p>}
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Deadline <span className="text-red-500">*</span></label>
                  <input {...register("deadline")} type="date" className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500" data-testid="input-deadline" />
                  {errors.deadline && <p className="text-xs text-red-500 mt-1">{errors.deadline.message}</p>}
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2 border-t border-gray-100">
                <button type="submit" className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors" data-testid="button-save-draft">
                  Save as Draft
                </button>
                <button type="button" onClick={handleSubmit(d => onSave(d, true))} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors" data-testid="button-submit-goal">
                  Submit for Approval
                </button>
                <button type="button" onClick={() => navigate("/employee/goals")} className="ml-auto px-4 py-2 text-gray-500 rounded-lg text-sm hover:bg-gray-50">Cancel</button>
              </div>
            </form>
          </div>
        </div>

        {/* Weightage Summary */}
        <div className="space-y-4">
          <div className={`bg-white rounded-lg border shadow-sm p-5 ${projectedTotal > 100 ? "border-red-300" : projectedTotal === 100 ? "border-green-300" : "border-gray-200"}`}>
            <h3 className="text-sm font-semibold text-gray-700 mb-4">Weightage Summary</h3>
            <div className="space-y-3">
              <div className="flex justify-between text-xs">
                <span className="text-gray-500">Other goals</span>
                <span className="font-semibold">{otherGoalsWeightage}%</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-gray-500">This goal</span>
                <span className="font-semibold text-blue-600">{watchedWeightage || 0}%</span>
              </div>
              <div className="border-t border-gray-100 pt-2 flex justify-between text-sm font-bold">
                <span>Projected Total</span>
                <span className={projectedTotal > 100 ? "text-red-600" : projectedTotal === 100 ? "text-green-600" : "text-gray-900"}>{projectedTotal}%</span>
              </div>
              <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className={`h-full rounded-full transition-all ${projectedTotal > 100 ? "bg-red-500" : projectedTotal === 100 ? "bg-green-500" : "bg-blue-500"}`} style={{ width: `${Math.min(100, projectedTotal)}%` }} />
              </div>
            </div>
            {projectedTotal === 100 && (
              <div className="mt-3 flex items-center gap-1.5 text-xs text-green-600">
                <CheckCircle size={12} />
                Total weightage is exactly 100%
              </div>
            )}
            {projectedTotal > 100 && (
              <div className="mt-3 flex items-center gap-1.5 text-xs text-red-500">
                <AlertCircle size={12} />
                Exceeds 100% by {projectedTotal - 100}%
              </div>
            )}
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="text-xs font-semibold text-blue-700 mb-2">Validation Rules</h4>
            <ul className="space-y-1.5 text-xs text-blue-600">
              <li className="flex items-center gap-1.5">
                {myGoals.length < 8 ? <CheckCircle size={11} /> : <AlertCircle size={11} className="text-red-500" />}
                Max 8 goals per cycle ({myGoals.length}/8)
              </li>
              <li className="flex items-center gap-1.5">
                {Number(watchedWeightage) >= 10 ? <CheckCircle size={11} /> : <AlertCircle size={11} className="text-red-500" />}
                Min 10% weightage per goal
              </li>
              <li className="flex items-center gap-1.5">
                {projectedTotal === 100 ? <CheckCircle size={11} /> : <AlertCircle size={11} className="text-amber-500" />}
                Total must equal exactly 100%
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
