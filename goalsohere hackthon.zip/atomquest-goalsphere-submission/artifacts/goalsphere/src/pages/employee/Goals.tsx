import { useState, useMemo } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Target, Plus, Eye, Edit, Trash2, Send, ChevronRight, Lock, AlertCircle } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useData } from "@/contexts/DataContext";
import { calculateGoalProgress, calculateOverallProgress, getTotalWeightage } from "@/lib/progress";
import { GoalStatusBadge, AchievementStatusBadge } from "@/components/shared/StatusBadge";
import { GoalProgressBar } from "@/components/shared/GoalProgressBar";
import { PageHeader } from "@/components/shared/PageHeader";
import type { GoalStatus } from "@/data/mockData";

export default function EmployeeGoals() {
  const { currentUser } = useAuth();
  const { goals, cycles, updateGoal, deleteGoal, addAuditLog, addNotification } = useData();
  const [filterStatus, setFilterStatus] = useState<string>("All");
  const [selectedGoal, setSelectedGoal] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  const activeCycle = cycles.find(c => c.status === "Active");
  const myGoals = useMemo(() =>
    goals.filter(g => g.employeeId === currentUser?.id && g.cycleId === (activeCycle?.id ?? "cy3")),
    [goals, currentUser, activeCycle]
  );
  const filteredGoals = filterStatus === "All" ? myGoals : myGoals.filter(g => g.status === filterStatus);
  const totalWeightage = getTotalWeightage(myGoals);
  const overallProgress = calculateOverallProgress(myGoals);

  const handleSubmit = (goalId: string) => {
    updateGoal(goalId, { status: "Submitted" });
    addAuditLog({ id: `al-${Date.now()}`, userId: currentUser!.id, action: "Goal Submitted", entityType: "Goal", entityId: goalId, details: `${currentUser!.name} submitted goal for review`, timestamp: new Date().toISOString() });
  };

  const handleDelete = (goalId: string) => {
    deleteGoal(goalId);
    setShowDeleteConfirm(null);
    addAuditLog({ id: `al-${Date.now()}`, userId: currentUser!.id, action: "Goal Deleted", entityType: "Goal", entityId: goalId, details: `${currentUser!.name} deleted a goal`, timestamp: new Date().toISOString() });
  };

  const canEdit = (status: GoalStatus) => status === "Draft" || status === "Rework";
  const weightageRemaining = 100 - totalWeightage;

  const detailedGoal = selectedGoal ? myGoals.find(g => g.id === selectedGoal) : null;

  return (
    <div data-testid="employee-goals">
      <PageHeader
        title="My Goals"
        subtitle={`${activeCycle?.name ?? "Current Cycle"} — ${myGoals.length}/8 goals`}
        actions={
          myGoals.length < 8 ? (
            <Link href="/employee/goals/new">
              <a className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors" data-testid="button-new-goal">
                <Plus size={14} />
                Add Goal
              </a>
            </Link>
          ) : (
            <span className="text-xs text-amber-600 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-lg">Maximum 8 goals reached</span>
          )
        }
      />

      {/* Weightage Summary */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4">
          <p className="text-xs text-gray-500">Weightage Used</p>
          <p className="text-xl font-bold text-gray-900 mt-1">{totalWeightage}%</p>
          <GoalProgressBar progress={totalWeightage} showLabel={false} className="mt-2" />
        </div>
        <div className={`rounded-lg border shadow-sm p-4 ${weightageRemaining === 0 ? "bg-green-50 border-green-200" : "bg-white border-gray-200"}`}>
          <p className="text-xs text-gray-500">Remaining</p>
          <p className={`text-xl font-bold mt-1 ${weightageRemaining === 0 ? "text-green-700" : weightageRemaining < 0 ? "text-red-600" : "text-gray-900"}`}>{Math.max(0, weightageRemaining)}%</p>
          {totalWeightage === 100 && <p className="text-xs text-green-600 mt-1">Total = 100% ✓</p>}
          {totalWeightage > 100 && <p className="text-xs text-red-500 mt-1">Exceeds 100%!</p>}
        </div>
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4">
          <p className="text-xs text-gray-500">Overall Progress</p>
          <p className="text-xl font-bold text-gray-900 mt-1">{overallProgress}%</p>
          <GoalProgressBar progress={overallProgress} showLabel={false} className="mt-2" />
        </div>
      </div>

      {/* Validation Alert */}
      {totalWeightage !== 100 && myGoals.length > 0 && (
        <div className="mb-4 flex items-center gap-2 px-4 py-3 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-700">
          <AlertCircle size={16} />
          {totalWeightage < 100
            ? `Weightage is ${totalWeightage}%. Add ${100 - totalWeightage}% more to reach 100% before submitting.`
            : `Weightage exceeds 100% by ${totalWeightage - 100}%. Please adjust goal weightages.`}
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex gap-1 mb-4 bg-gray-100 p-1 rounded-lg w-fit">
        {["All", "Draft", "Submitted", "Approved", "Rework", "Rejected"].map(s => (
          <button
            key={s}
            onClick={() => setFilterStatus(s)}
            data-testid={`filter-${s.toLowerCase()}`}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${filterStatus === s ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}
          >
            {s}
            {s !== "All" && <span className="ml-1 text-[10px] text-gray-400">({myGoals.filter(g => g.status === s).length})</span>}
          </button>
        ))}
      </div>

      {/* Goals Table */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
        {filteredGoals.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-gray-400">
            <Target size={32} className="mb-3 opacity-40" />
            <p className="text-sm">No goals found</p>
            <Link href="/employee/goals/new">
              <a className="mt-3 text-xs text-blue-600 hover:underline">Create your first goal</a>
            </Link>
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                {["Goal Title", "Thrust Area", "UoM", "Target", "Weightage", "Progress", "Deadline", "Status", "Actions"].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredGoals.map((goal, idx) => (
                <motion.tr
                  key={goal.id}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.03 }}
                  className="hover:bg-gray-50 transition-colors"
                  data-testid={`goal-row-${goal.id}`}
                >
                  <td className="px-4 py-3">
                    <div>
                      <p className="font-medium text-gray-900 max-w-48 truncate">{goal.title}</p>
                      {goal.isShared && <span className="text-[10px] bg-indigo-50 text-indigo-600 border border-indigo-100 px-1.5 py-0.5 rounded-full">Shared</span>}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-500">{goal.thrustArea}</td>
                  <td className="px-4 py-3 text-xs text-gray-600">{goal.unitOfMeasurement}</td>
                  <td className="px-4 py-3 text-xs text-gray-700 font-medium">{goal.target.toLocaleString()}</td>
                  <td className="px-4 py-3 text-xs font-semibold text-gray-700">{goal.weightage}%</td>
                  <td className="px-4 py-3 w-32">
                    <GoalProgressBar progress={calculateGoalProgress(goal)} size="sm" />
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-500">{goal.deadline}</td>
                  <td className="px-4 py-3">
                    <GoalStatusBadge status={goal.status} />
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => setSelectedGoal(goal.id === selectedGoal ? null : goal.id)} className="p-1 text-gray-400 hover:text-blue-600 rounded" data-testid={`button-view-goal-${goal.id}`}>
                        <Eye size={14} />
                      </button>
                      {canEdit(goal.status) && (
                        <>
                          <Link href={`/employee/goals/${goal.id}/edit`}>
                            <a className="p-1 text-gray-400 hover:text-blue-600 rounded" data-testid={`button-edit-goal-${goal.id}`}>
                              <Edit size={14} />
                            </a>
                          </Link>
                          <button onClick={() => handleSubmit(goal.id)} className="p-1 text-gray-400 hover:text-green-600 rounded" title="Submit" data-testid={`button-submit-goal-${goal.id}`}>
                            <Send size={14} />
                          </button>
                          <button onClick={() => setShowDeleteConfirm(goal.id)} className="p-1 text-gray-400 hover:text-red-500 rounded" data-testid={`button-delete-goal-${goal.id}`}>
                            <Trash2 size={14} />
                          </button>
                        </>
                      )}
                      {(goal.status === "Approved" || goal.status === "Locked") && (
                        <Lock size={12} className="text-gray-300 ml-1" />
                      )}
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Delete Confirm */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-80 shadow-xl">
            <h3 className="font-semibold text-gray-900 mb-2">Delete Goal</h3>
            <p className="text-sm text-gray-500 mb-4">Are you sure you want to delete this goal? This action cannot be undone.</p>
            <div className="flex gap-2">
              <button onClick={() => setShowDeleteConfirm(null)} className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50">Cancel</button>
              <button onClick={() => handleDelete(showDeleteConfirm)} className="flex-1 px-3 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700" data-testid="button-confirm-delete">Delete</button>
            </div>
          </div>
        </div>
      )}

      {/* Goal Detail Panel */}
      {detailedGoal && (
        <div className="mt-4 bg-white rounded-lg border border-gray-200 shadow-sm p-5">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="font-semibold text-gray-900">{detailedGoal.title}</h3>
              <p className="text-xs text-gray-500 mt-0.5">{detailedGoal.thrustArea} · {detailedGoal.unitOfMeasurement}</p>
            </div>
            <GoalStatusBadge status={detailedGoal.status} />
          </div>
          <p className="text-sm text-gray-600 mb-4">{detailedGoal.description}</p>
          <div className="grid grid-cols-3 gap-4 text-xs">
            <div><p className="text-gray-400">Target</p><p className="font-semibold text-gray-800">{detailedGoal.target.toLocaleString()}</p></div>
            <div><p className="text-gray-400">Weightage</p><p className="font-semibold text-gray-800">{detailedGoal.weightage}%</p></div>
            <div><p className="text-gray-400">Deadline</p><p className="font-semibold text-gray-800">{detailedGoal.deadline}</p></div>
          </div>
          {detailedGoal.managerComments && (
            <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800">
              <p className="font-medium">Manager Comments:</p>
              <p className="mt-1">{detailedGoal.managerComments}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
