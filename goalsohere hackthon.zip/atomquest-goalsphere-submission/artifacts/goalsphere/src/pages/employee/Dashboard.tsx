import { useMemo } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Target, CheckCircle, Clock, TrendingUp, AlertCircle, Bell, ChevronRight, Calendar } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";
import { useAuth } from "@/contexts/AuthContext";
import { useData } from "@/contexts/DataContext";
import { calculateGoalProgress, calculateOverallProgress } from "@/lib/progress";
import { KPICard } from "@/components/shared/KPICard";
import { GoalStatusBadge } from "@/components/shared/StatusBadge";
import { GoalProgressBar } from "@/components/shared/GoalProgressBar";
import { PageHeader } from "@/components/shared/PageHeader";

const PIE_COLORS = { Approved: "#22c55e", Submitted: "#f59e0b", Draft: "#94a3b8", Rejected: "#ef4444", Rework: "#f97316", Locked: "#8b5cf6" };
const QUARTERLY_DATA = [
  { quarter: "Q1", progress: 78, target: 80 },
  { quarter: "Q2", progress: 85, target: 80 },
  { quarter: "Q3", progress: 72, target: 80 },
];

export default function EmployeeDashboard() {
  const { currentUser } = useAuth();
  const { goals, cycles, notifications } = useData();

  const myGoals = useMemo(() => goals.filter(g => g.employeeId === currentUser?.id), [goals, currentUser]);
  const activeCycle = cycles.find(c => c.status === "Active");
  const cycleGoals = myGoals.filter(g => g.cycleId === activeCycle?.id);
  const approvedGoals = cycleGoals.filter(g => g.status === "Approved" || g.status === "Locked");
  const completedGoals = approvedGoals.filter(g => g.achievementStatus === "Completed");
  const pendingGoals = cycleGoals.filter(g => g.status === "Draft" || g.status === "Submitted" || g.status === "Rework");
  const overallProgress = calculateOverallProgress(cycleGoals);
  const myNotifications = notifications.filter(n => n.userId === currentUser?.id && !n.read).slice(0, 5);

  const today = new Date();
  const upcomingDeadlines = approvedGoals
    .filter(g => {
      const d = new Date(g.deadline);
      const diff = (d.getTime() - today.getTime()) / (1000 * 60 * 60 * 24);
      return diff >= 0 && diff <= 30;
    })
    .sort((a, b) => a.deadline.localeCompare(b.deadline))
    .slice(0, 5);

  const statusDistribution = Object.entries(
    cycleGoals.reduce((acc, g) => { acc[g.status] = (acc[g.status] || 0) + 1; return acc; }, {} as Record<string, number>)
  ).map(([name, value]) => ({ name, value }));

  return (
    <div data-testid="employee-dashboard">
      <PageHeader
        title={`Welcome back, ${currentUser?.name.split(" ")[0]}`}
        subtitle={activeCycle ? `${activeCycle.name} — ${activeCycle.phase.replace(/([A-Z])/g, " $1").trim()}` : "No active cycle"}
        actions={
          <Link href="/employee/goals/new">
            <a className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors" data-testid="button-add-goal">
              <Target size={14} />
              New Goal
            </a>
          </Link>
        }
      />

      {/* Active Cycle Banner */}
      {activeCycle && (
        <div className="mb-6 flex items-center gap-3 px-4 py-3 bg-blue-600 text-white rounded-lg text-sm">
          <Calendar size={16} />
          <span className="font-medium">{activeCycle.name} Active</span>
          <span className="text-blue-200">|</span>
          <span className="text-blue-100">{activeCycle.phase.replace(/([A-Z])/g, " $1").trim()}</span>
          <span className="ml-auto text-blue-100 text-xs">Ends {new Date(activeCycle.endDate).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</span>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <KPICard title="Total Goals" value={cycleGoals.length} subtitle="This cycle" icon={<Target size={18} className="text-blue-600" />} iconBg="bg-blue-50" />
        <KPICard title="Approved" value={approvedGoals.length} subtitle="Goals locked in" icon={<CheckCircle size={18} className="text-green-600" />} iconBg="bg-green-50" />
        <KPICard title="Pending" value={pendingGoals.length} subtitle="Awaiting action" icon={<Clock size={18} className="text-amber-600" />} iconBg="bg-amber-50" />
        <KPICard title="Overall Progress" value={`${overallProgress}%`} subtitle="Weighted average" icon={<TrendingUp size={18} className="text-purple-600" />} iconBg="bg-purple-50" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quarterly Progress Chart */}
        <div className="lg:col-span-2 bg-white rounded-lg border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">Quarterly Progress Trend</h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={QUARTERLY_DATA}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="quarter" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} domain={[0, 100]} unit="%" />
              <Tooltip formatter={(v: number) => `${v}%`} />
              <Line type="monotone" dataKey="progress" stroke="#2563eb" strokeWidth={2} dot={{ r: 4 }} name="Progress" />
              <Line type="monotone" dataKey="target" stroke="#94a3b8" strokeWidth={1.5} strokeDasharray="4 4" dot={false} name="Target" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Goal Status Distribution */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">Goal Status Distribution</h3>
          {statusDistribution.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={statusDistribution} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" paddingAngle={2}>
                  {statusDistribution.map((entry) => (
                    <Cell key={entry.name} fill={PIE_COLORS[entry.name as keyof typeof PIE_COLORS] ?? "#94a3b8"} />
                  ))}
                </Pie>
                <Legend iconSize={10} wrapperStyle={{ fontSize: 11 }} />
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-48 text-gray-400 text-sm">No goals yet</div>
          )}
        </div>

        {/* My Goals Quick View */}
        <div className="lg:col-span-2 bg-white rounded-lg border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-gray-700">My Goals</h3>
            <Link href="/employee/goals">
              <a className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1" data-testid="link-view-all-goals">View all <ChevronRight size={12} /></a>
            </Link>
          </div>
          <div className="space-y-3">
            {cycleGoals.slice(0, 4).map(goal => (
              <div key={goal.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg" data-testid={`goal-row-${goal.id}`}>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-gray-900 truncate">{goal.title}</p>
                  <p className="text-[11px] text-gray-500 mt-0.5">{goal.thrustArea}</p>
                  <GoalProgressBar progress={calculateGoalProgress(goal)} size="sm" className="mt-1.5" />
                </div>
                <div className="flex-shrink-0">
                  <GoalStatusBadge status={goal.status} />
                </div>
              </div>
            ))}
            {cycleGoals.length === 0 && (
              <div className="text-center py-8 text-gray-400 text-sm">
                <Target size={24} className="mx-auto mb-2 opacity-40" />
                No goals for this cycle
              </div>
            )}
          </div>
        </div>

        {/* Right Panel */}
        <div className="space-y-4">
          {/* Upcoming Deadlines */}
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
            <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
              <AlertCircle size={14} className="text-amber-500" />
              Upcoming Deadlines
            </h3>
            <div className="space-y-2.5">
              {upcomingDeadlines.length === 0 ? (
                <p className="text-xs text-gray-400">No upcoming deadlines</p>
              ) : upcomingDeadlines.map(g => {
                const daysLeft = Math.ceil((new Date(g.deadline).getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
                return (
                  <div key={g.id} className="flex items-start gap-2" data-testid={`deadline-${g.id}`}>
                    <div className={`mt-0.5 w-1.5 h-1.5 rounded-full flex-shrink-0 ${daysLeft <= 7 ? "bg-red-500" : "bg-amber-400"}`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-gray-800 truncate">{g.title}</p>
                      <p className={`text-[10px] font-medium ${daysLeft <= 7 ? "text-red-500" : "text-amber-600"}`}>{daysLeft}d left</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Notifications */}
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                <Bell size={14} className="text-blue-500" />
                Recent Notifications
              </h3>
              <Link href="/employee/notifications">
                <a className="text-xs text-blue-600" data-testid="link-all-notifications">All</a>
              </Link>
            </div>
            <div className="space-y-2.5">
              {myNotifications.length === 0 ? (
                <p className="text-xs text-gray-400">No new notifications</p>
              ) : myNotifications.map(n => (
                <div key={n.id} className="text-xs text-gray-600 p-2 bg-blue-50 rounded-md" data-testid={`notification-${n.id}`}>
                  {n.message.length > 80 ? n.message.slice(0, 80) + "..." : n.message}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
