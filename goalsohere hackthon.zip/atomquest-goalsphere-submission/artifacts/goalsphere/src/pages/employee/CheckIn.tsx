import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { CheckSquare, Save, AlertCircle } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useData } from "@/contexts/DataContext";
import { calculateGoalProgress } from "@/lib/progress";
import { GoalProgressBar } from "@/components/shared/GoalProgressBar";
import { AchievementStatusBadge, GoalStatusBadge } from "@/components/shared/StatusBadge";
import { PageHeader } from "@/components/shared/PageHeader";
import type { AchievementStatus } from "@/data/mockData";

export default function CheckIn() {
  const { currentUser } = useAuth();
  const { goals, cycles, updateGoal, addAuditLog } = useData();
  const [saved, setSaved] = useState<Record<string, boolean>>({});
  const [localData, setLocalData] = useState<Record<string, { actual: string; status: AchievementStatus; remarks: string }>>({});

  const activeCycle = cycles.find(c => c.status === "Active");
  const approvedGoals = useMemo(() =>
    goals.filter(g => g.employeeId === currentUser?.id && g.cycleId === (activeCycle?.id ?? "cy3") && (g.status === "Approved" || g.status === "Locked")),
    [goals, currentUser, activeCycle]
  );

  const getLocal = (id: string) => localData[id] ?? {
    actual: String(goals.find(g => g.id === id)?.actualAchievement ?? ""),
    status: (goals.find(g => g.id === id)?.achievementStatus ?? "NotStarted") as AchievementStatus,
    remarks: goals.find(g => g.id === id)?.remarks ?? "",
  };

  const setField = (id: string, field: string, value: string) => {
    setLocalData(prev => ({ ...prev, [id]: { ...getLocal(id), [field]: value } }));
  };

  const handleSave = (goalId: string) => {
    const d = getLocal(goalId);
    updateGoal(goalId, {
      actualAchievement: d.actual !== "" ? Number(d.actual) : undefined,
      achievementStatus: d.status,
      remarks: d.remarks,
    });
    addAuditLog({ id: `al-${Date.now()}`, userId: currentUser!.id, action: "Check-in Updated", entityType: "Goal", entityId: goalId, details: `${currentUser!.name} updated Q3 check-in: actual=${d.actual}`, timestamp: new Date().toISOString() });
    setSaved(prev => ({ ...prev, [goalId]: true }));
    setTimeout(() => setSaved(prev => ({ ...prev, [goalId]: false })), 2000);
  };

  const handleSaveAll = () => {
    approvedGoals.forEach(g => handleSave(g.id));
  };

  return (
    <div data-testid="check-in-page">
      <PageHeader
        title="Quarterly Check-in"
        subtitle={activeCycle ? `${activeCycle.name} — ${activeCycle.phase.replace(/([A-Z])/g, " $1").trim()}` : "No active cycle"}
        actions={
          <button onClick={handleSaveAll} className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors" data-testid="button-save-all-checkins">
            <Save size={14} />
            Save All
          </button>
        }
      />

      {!activeCycle && (
        <div className="flex items-center gap-2 p-4 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-700 mb-6">
          <AlertCircle size={16} />
          No active goal cycle. Check-ins are only available during an active cycle.
        </div>
      )}

      {approvedGoals.length === 0 ? (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-12 text-center text-gray-400">
          <CheckSquare size={32} className="mx-auto mb-3 opacity-40" />
          <p className="text-sm">No approved goals to check in for this cycle.</p>
          <p className="text-xs mt-1">Goals must be approved by your manager before you can check in.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {approvedGoals.map((goal, idx) => {
            const local = getLocal(goal.id);
            const previewActual = local.actual !== "" ? Number(local.actual) : goal.actualAchievement;
            const previewGoal = { ...goal, actualAchievement: previewActual };
            const progress = calculateGoalProgress(previewGoal);

            return (
              <motion.div
                key={goal.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="bg-white rounded-lg border border-gray-200 shadow-sm p-5"
                data-testid={`checkin-row-${goal.id}`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-medium text-gray-900">{goal.title}</h3>
                    <p className="text-xs text-gray-500 mt-0.5">{goal.thrustArea} · {goal.unitOfMeasurement}</p>
                  </div>
                  <GoalStatusBadge status={goal.status} />
                </div>

                <div className="grid grid-cols-4 gap-4 text-xs mb-4">
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-gray-400">Target</p>
                    <p className="font-bold text-gray-900 text-base mt-1">{goal.target.toLocaleString()}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-gray-400">Previous Actual</p>
                    <p className="font-bold text-gray-900 text-base mt-1">{goal.actualAchievement?.toLocaleString() ?? "—"}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-gray-400">Weightage</p>
                    <p className="font-bold text-gray-900 text-base mt-1">{goal.weightage}%</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-gray-400">Deadline</p>
                    <p className="font-bold text-gray-900 text-base mt-1">{goal.deadline}</p>
                  </div>
                </div>

                <div className="mb-4">
                  <p className="text-xs text-gray-500 mb-1">Current Progress</p>
                  <GoalProgressBar progress={progress} />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Actual Achievement</label>
                    <input
                      type="number"
                      value={local.actual}
                      onChange={e => setField(goal.id, "actual", e.target.value)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500"
                      placeholder={`Target: ${goal.target}`}
                      data-testid={`input-actual-${goal.id}`}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Status</label>
                    <select
                      value={local.status}
                      onChange={e => setField(goal.id, "status", e.target.value as AchievementStatus)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500"
                      data-testid={`select-status-${goal.id}`}
                    >
                      <option value="NotStarted">Not Started</option>
                      <option value="OnTrack">On Track</option>
                      <option value="Completed">Completed</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Remarks</label>
                    <input
                      type="text"
                      value={local.remarks}
                      onChange={e => setField(goal.id, "remarks", e.target.value)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500"
                      placeholder="Brief update..."
                      data-testid={`input-remarks-${goal.id}`}
                    />
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-between">
                  <AchievementStatusBadge status={local.status as AchievementStatus} />
                  <button
                    onClick={() => handleSave(goal.id)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${saved[goal.id] ? "bg-green-600 text-white" : "bg-blue-600 text-white hover:bg-blue-700"}`}
                    data-testid={`button-save-checkin-${goal.id}`}
                  >
                    <Save size={14} />
                    {saved[goal.id] ? "Saved!" : "Save"}
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
