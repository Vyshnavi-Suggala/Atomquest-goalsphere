import { useState } from "react";
import { motion } from "framer-motion";
import { Settings, Calendar, Lock, Unlock, Play, ChevronRight } from "lucide-react";
import { useData } from "@/contexts/DataContext";
import { useAuth } from "@/contexts/AuthContext";
import { CycleStatusBadge } from "@/components/shared/StatusBadge";
import { PageHeader } from "@/components/shared/PageHeader";
import type { CyclePhase, CycleStatus } from "@/data/mockData";

const PHASES: CyclePhase[] = ["GoalSetting", "Q1Checkin", "Q2Checkin", "Q3Checkin", "AnnualReview"];
const phaseLabel = (p: CyclePhase) => p.replace(/([A-Z])/g, " $1").trim();

export default function AdminCycles() {
  const { currentUser } = useAuth();
  const { cycles, updateCycle, addAuditLog } = useData();
  const [editingCycle, setEditingCycle] = useState<string | null>(null);
  const [editPhase, setEditPhase] = useState<CyclePhase>("GoalSetting");

  const activeCycle = cycles.find(c => c.status === "Active");

  const handlePhaseChange = (cycleId: string, phase: CyclePhase) => {
    updateCycle(cycleId, { phase });
    addAuditLog({ id: `al-${Date.now()}`, userId: currentUser!.id, action: "Cycle Updated", entityType: "Cycle", entityId: cycleId, details: `Changed phase to ${phase}`, timestamp: new Date().toISOString() });
    setEditingCycle(null);
  };

  const handleStatusChange = (cycleId: string, status: CycleStatus) => {
    if (status === "Active") {
      cycles.forEach(c => { if (c.id !== cycleId && c.status === "Active") updateCycle(c.id, { status: "Closed" }); });
    }
    updateCycle(cycleId, { status });
    addAuditLog({ id: `al-${Date.now()}`, userId: currentUser!.id, action: status === "Active" ? "Cycle Opened" : "Cycle Closed", entityType: "Cycle", entityId: cycleId, details: `Admin ${status === "Active" ? "opened" : "closed"} cycle`, timestamp: new Date().toISOString() });
  };

  return (
    <div data-testid="admin-cycles">
      <PageHeader title="Goal Cycle Management" subtitle="Configure and manage quarterly goal cycles" />

      {/* Active Cycle Banner */}
      {activeCycle && (
        <div className="mb-6 flex items-center gap-3 px-4 py-3 bg-blue-600 text-white rounded-lg text-sm">
          <Play size={16} />
          <span className="font-semibold">{activeCycle.name} is Active</span>
          <span className="text-blue-200">|</span>
          <span className="text-blue-100">Current Phase: {phaseLabel(activeCycle.phase)}</span>
          <span className="ml-auto text-blue-100 text-xs">
            {new Date(activeCycle.startDate).toLocaleDateString()} — {new Date(activeCycle.endDate).toLocaleDateString()}
          </span>
        </div>
      )}

      <div className="space-y-4">
        {cycles.map((cycle, idx) => (
          <motion.div
            key={cycle.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.06 }}
            className={`bg-white rounded-lg border shadow-sm p-5 ${cycle.status === "Active" ? "border-blue-300" : "border-gray-200"}`}
            data-testid={`cycle-card-${cycle.id}`}
          >
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-3 mb-1">
                  <Calendar size={16} className="text-gray-400" />
                  <h3 className="font-semibold text-gray-900">{cycle.name}</h3>
                  <CycleStatusBadge status={cycle.status} />
                </div>
                <p className="text-xs text-gray-500 ml-7">
                  {new Date(cycle.startDate).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })} —{" "}
                  {new Date(cycle.endDate).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                </p>
              </div>

              <div className="flex items-center gap-2">
                {cycle.status === "Active" ? (
                  <button onClick={() => handleStatusChange(cycle.id, "Closed")} className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-600 text-white text-xs font-medium rounded-lg hover:bg-gray-700" data-testid={`button-close-cycle-${cycle.id}`}>
                    <Lock size={12} /> Close Cycle
                  </button>
                ) : cycle.status === "Upcoming" || cycle.status === "Closed" ? (
                  <button onClick={() => handleStatusChange(cycle.id, "Active")} className="flex items-center gap-1.5 px-3 py-1.5 bg-green-600 text-white text-xs font-medium rounded-lg hover:bg-green-700" data-testid={`button-open-cycle-${cycle.id}`}>
                    <Unlock size={12} /> Open Cycle
                  </button>
                ) : null}
              </div>
            </div>

            {/* Phase management */}
            <div className="mt-4 border-t border-gray-100 pt-4">
              <div className="flex items-center justify-between mb-3">
                <p className="text-xs font-medium text-gray-600">Current Phase: <span className="text-blue-600">{phaseLabel(cycle.phase)}</span></p>
                {editingCycle === cycle.id ? (
                  <button onClick={() => setEditingCycle(null)} className="text-xs text-gray-500 hover:text-gray-700">Cancel</button>
                ) : (
                  <button onClick={() => { setEditingCycle(cycle.id); setEditPhase(cycle.phase); }} className="flex items-center gap-1 text-xs text-blue-600 hover:text-blue-700" data-testid={`button-change-phase-${cycle.id}`}>
                    <Settings size={11} /> Change Phase
                  </button>
                )}
              </div>

              {/* Phase progress display */}
              <div className="flex items-center gap-1">
                {PHASES.map((phase, i) => {
                  const currentIdx = PHASES.indexOf(cycle.phase);
                  const isDone = i < currentIdx;
                  const isCurrent = i === currentIdx;
                  return (
                    <div key={phase} className="flex items-center gap-1 flex-1">
                      <div className={`flex-1 h-1.5 rounded-full ${isDone ? "bg-blue-500" : isCurrent ? "bg-blue-300" : "bg-gray-100"}`} />
                      {i === PHASES.length - 1 && <div className={`w-2 h-2 rounded-full ${isDone || isCurrent ? "bg-blue-500" : "bg-gray-200"}`} />}
                    </div>
                  );
                })}
              </div>
              <div className="flex justify-between mt-1">
                {PHASES.map(p => (
                  <span key={p} className={`text-[10px] ${cycle.phase === p ? "text-blue-600 font-semibold" : "text-gray-400"}`}>{phaseLabel(p).split(" ")[0]}</span>
                ))}
              </div>

              {editingCycle === cycle.id && (
                <div className="mt-3 p-3 bg-gray-50 rounded-lg border border-gray-200">
                  <p className="text-xs font-medium text-gray-600 mb-2">Select new phase:</p>
                  <div className="flex flex-wrap gap-2">
                    {PHASES.map(phase => (
                      <button
                        key={phase}
                        onClick={() => handlePhaseChange(cycle.id, phase)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${editPhase === phase ? "bg-blue-600 text-white" : "bg-white border border-gray-300 text-gray-600 hover:border-blue-400"}`}
                        data-testid={`button-set-phase-${phase}`}
                      >
                        {phaseLabel(phase)}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
