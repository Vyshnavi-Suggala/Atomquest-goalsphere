import { useState } from "react";
import { motion } from "framer-motion";
import { History, Search, CheckCircle, XCircle, Settings, RotateCcw, Target, Unlock, Star } from "lucide-react";
import { useData } from "@/contexts/DataContext";
import { PageHeader } from "@/components/shared/PageHeader";

const actionIcons: Record<string, { icon: typeof CheckCircle; color: string; bg: string }> = {
  "Goal Approved":    { icon: CheckCircle, color: "text-green-600", bg: "bg-green-50" },
  "Goal Rejected":    { icon: XCircle, color: "text-red-500", bg: "bg-red-50" },
  "Goal Submitted":   { icon: Target, color: "text-blue-600", bg: "bg-blue-50" },
  "Goal Created":     { icon: Target, color: "text-blue-500", bg: "bg-blue-50" },
  "Goal Updated":     { icon: RotateCcw, color: "text-amber-600", bg: "bg-amber-50" },
  "Goal Deleted":     { icon: XCircle, color: "text-red-400", bg: "bg-red-50" },
  "Goal Returned for Rework": { icon: RotateCcw, color: "text-orange-500", bg: "bg-orange-50" },
  "Cycle Updated":    { icon: Settings, color: "text-purple-600", bg: "bg-purple-50" },
  "Cycle Closed":     { icon: Settings, color: "text-gray-600", bg: "bg-gray-50" },
  "Cycle Opened":     { icon: Settings, color: "text-green-600", bg: "bg-green-50" },
  "Goal Unlocked":    { icon: Unlock, color: "text-purple-600", bg: "bg-purple-50" },
  "Check-in Updated": { icon: CheckCircle, color: "text-teal-600", bg: "bg-teal-50" },
  "Performance Rated": { icon: Star, color: "text-amber-500", bg: "bg-amber-50" },
};

export default function AdminAudit() {
  const { auditLogs, users } = useData();
  const [search, setSearch] = useState("");
  const [filterAction, setFilterAction] = useState("All");
  const [view, setView] = useState<"table" | "timeline">("table");

  const actionTypes = Array.from(new Set(auditLogs.map(l => l.action)));
  const filtered = auditLogs
    .filter(l => {
      const matchSearch = l.details.toLowerCase().includes(search.toLowerCase()) || users.find(u => u.id === l.userId)?.name.toLowerCase().includes(search.toLowerCase());
      const matchAction = filterAction === "All" || l.action === filterAction;
      return matchSearch && matchAction;
    })
    .sort((a, b) => b.timestamp.localeCompare(a.timestamp));

  return (
    <div data-testid="admin-audit">
      <PageHeader
        title="Audit Logs"
        subtitle={`${auditLogs.length} total activity records`}
        actions={
          <div className="flex bg-gray-100 p-1 rounded-lg gap-1">
            <button onClick={() => setView("table")} className={`px-3 py-1 text-xs font-medium rounded-md ${view === "table" ? "bg-white text-gray-900 shadow-sm" : "text-gray-500"}`} data-testid="button-view-table">Table</button>
            <button onClick={() => setView("timeline")} className={`px-3 py-1 text-xs font-medium rounded-md ${view === "timeline" ? "bg-white text-gray-900 shadow-sm" : "text-gray-500"}`} data-testid="button-view-timeline">Timeline</button>
          </div>
        }
      />

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-5">
        <div className="relative flex-1 min-w-48">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input type="search" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search activities..." className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500" data-testid="input-search-audit" />
        </div>
        <select value={filterAction} onChange={e => setFilterAction(e.target.value)} className="border border-gray-300 rounded-lg px-3 py-2 text-sm" data-testid="select-filter-action">
          <option value="All">All Actions</option>
          {actionTypes.map(a => <option key={a} value={a}>{a}</option>)}
        </select>
      </div>

      {view === "table" ? (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                {["Timestamp", "User", "Action", "Entity", "Details"].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map((log, idx) => {
                const user = users.find(u => u.id === log.userId);
                const config = actionIcons[log.action] ?? { icon: Target, color: "text-gray-500", bg: "bg-gray-50" };
                const Icon = config.icon;
                return (
                  <motion.tr key={log.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: idx * 0.02 }} className="hover:bg-gray-50" data-testid={`audit-row-${log.id}`}>
                    <td className="px-4 py-3 text-xs text-gray-500 whitespace-nowrap">{new Date(log.timestamp).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        <div className="w-5 h-5 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
                          <span className="text-[8px] font-bold text-white">{user?.initials ?? "?"}</span>
                        </div>
                        <span className="text-xs text-gray-700">{user?.name ?? "Unknown"}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full ${config.bg}`}>
                        <Icon size={11} className={config.color} />
                        <span className={`text-[11px] font-medium ${config.color}`}>{log.action}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-500">{log.entityType}</td>
                    <td className="px-4 py-3 text-xs text-gray-600 max-w-xs truncate">{log.details}</td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="text-center py-12 text-gray-400">
              <History size={28} className="mx-auto mb-2 opacity-40" />
              <p className="text-sm">No audit logs found</p>
            </div>
          )}
        </div>
      ) : (
        <div className="relative pl-6">
          <div className="absolute left-2 top-0 bottom-0 w-0.5 bg-gray-200" />
          <div className="space-y-4">
            {filtered.map((log, idx) => {
              const user = users.find(u => u.id === log.userId);
              const config = actionIcons[log.action] ?? { icon: Target, color: "text-gray-500", bg: "bg-gray-50" };
              const Icon = config.icon;
              return (
                <motion.div key={log.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: idx * 0.03 }} className="relative" data-testid={`audit-timeline-${log.id}`}>
                  <div className={`absolute -left-6 w-4 h-4 rounded-full border-2 border-white ${config.bg} flex items-center justify-center`}>
                    <Icon size={8} className={config.color} />
                  </div>
                  <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 ml-2">
                    <div className="flex items-start justify-between mb-1">
                      <span className={`text-xs font-semibold ${config.color}`}>{log.action}</span>
                      <span className="text-[10px] text-gray-400">{new Date(log.timestamp).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</span>
                    </div>
                    <p className="text-xs text-gray-600">{log.details}</p>
                    <p className="text-[10px] text-gray-400 mt-1">by {user?.name}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
