import { useState, useMemo } from "react";
import { FileText, Download, BarChart3 } from "lucide-react";
import { useData } from "@/contexts/DataContext";
import { exportPlannedVsActual, exportEmployeePerformance, exportDepartmentAnalytics } from "@/lib/csvExport";
import { calculateGoalProgress } from "@/lib/progress";
import { GoalStatusBadge, AchievementStatusBadge } from "@/components/shared/StatusBadge";
import { GoalProgressBar } from "@/components/shared/GoalProgressBar";
import { PageHeader } from "@/components/shared/PageHeader";

export default function AdminReports() {
  const { users, goals, cycles, ratings } = useData();
  const [activeReport, setActiveReport] = useState<string>("planned-vs-actual");
  const [filterDept, setFilterDept] = useState("All");

  const activeCycle = cycles.find(c => c.status === "Active");
  const employees = users.filter(u => u.role === "employee");
  const depts = Array.from(new Set(employees.map(u => u.department)));
  const cycleGoals = goals.filter(g => g.cycleId === (activeCycle?.id ?? "cy3"));

  const filteredEmployees = filterDept === "All" ? employees : employees.filter(u => u.department === filterDept);
  const filteredGoals = cycleGoals.filter(g => filteredEmployees.some(u => u.id === g.employeeId));

  const reports = [
    { id: "planned-vs-actual", label: "Planned vs Actual", icon: BarChart3 },
    { id: "employee-performance", label: "Employee Performance", icon: FileText },
    { id: "department-analytics", label: "Department Analytics", icon: BarChart3 },
  ];

  const deptSummary = useMemo(() => depts.map(dept => {
    const deptUsers = employees.filter(u => u.department === dept);
    const deptGoals = cycleGoals.filter(g => deptUsers.some(u => u.id === g.employeeId));
    const approved = deptGoals.filter(g => g.status === "Approved" || g.status === "Locked");
    const avgProgress = approved.length > 0
      ? Math.round(approved.reduce((s, g) => s + calculateGoalProgress(g), 0) / approved.length)
      : 0;
    return { dept, employees: deptUsers.length, totalGoals: deptGoals.length, approved: approved.length, avgProgress };
  }), [depts, employees, cycleGoals]);

  const handleExport = () => {
    if (activeReport === "planned-vs-actual") exportPlannedVsActual(filteredGoals, users);
    else if (activeReport === "employee-performance") exportEmployeePerformance(users, goals, ratings);
    else exportDepartmentAnalytics(users, goals);
  };

  return (
    <div data-testid="admin-reports">
      <PageHeader
        title="Reports"
        subtitle={`${activeCycle?.name} — data analysis and exports`}
        actions={
          <button onClick={handleExport} className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors" data-testid="button-export-csv">
            <Download size={14} />
            Export CSV
          </button>
        }
      />

      <div className="flex flex-wrap gap-3 mb-5">
        {/* Report selector */}
        <div className="flex gap-1 bg-gray-100 p-1 rounded-lg">
          {reports.map(r => {
            const Icon = r.icon;
            return (
              <button key={r.id} onClick={() => setActiveReport(r.id)} className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${activeReport === r.id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`} data-testid={`report-tab-${r.id}`}>
                <Icon size={12} />
                {r.label}
              </button>
            );
          })}
        </div>

        <select value={filterDept} onChange={e => setFilterDept(e.target.value)} className="border border-gray-300 rounded-lg px-3 py-2 text-sm" data-testid="select-filter-dept-report">
          <option value="All">All Departments</option>
          {depts.map(d => <option key={d} value={d}>{d}</option>)}
        </select>
      </div>

      {/* Planned vs Actual Report */}
      {activeReport === "planned-vs-actual" && (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden" data-testid="report-planned-vs-actual">
          <div className="px-5 py-3 border-b border-gray-100 bg-gray-50">
            <p className="text-xs font-medium text-gray-600">Planned vs Actual Achievement — {activeCycle?.name}</p>
          </div>
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                {["Employee", "Goal Title", "Thrust Area", "Target", "Actual", "Progress", "Status", "Achievement"].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredGoals.map(g => {
                const emp = users.find(u => u.id === g.employeeId);
                return (
                  <tr key={g.id} className="hover:bg-gray-50" data-testid={`report-row-${g.id}`}>
                    <td className="px-4 py-3 text-xs font-medium text-gray-900">{emp?.name}</td>
                    <td className="px-4 py-3 text-xs text-gray-700 max-w-36 truncate">{g.title}</td>
                    <td className="px-4 py-3 text-xs text-gray-500">{g.thrustArea.split(" ").slice(-1)[0]}</td>
                    <td className="px-4 py-3 text-xs font-medium text-gray-700">{g.target.toLocaleString()}</td>
                    <td className="px-4 py-3 text-xs font-semibold text-blue-700">{g.actualAchievement?.toLocaleString() ?? "—"}</td>
                    <td className="px-4 py-3 w-28"><GoalProgressBar progress={calculateGoalProgress(g)} size="sm" /></td>
                    <td className="px-4 py-3"><GoalStatusBadge status={g.status} /></td>
                    <td className="px-4 py-3"><AchievementStatusBadge status={g.achievementStatus} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Employee Performance Report */}
      {activeReport === "employee-performance" && (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden" data-testid="report-employee-performance">
          <div className="px-5 py-3 border-b border-gray-100 bg-gray-50">
            <p className="text-xs font-medium text-gray-600">Employee Performance Summary</p>
          </div>
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                {["Employee", "Department", "Job Title", "Total Goals", "Approved", "Avg Progress", "Latest Rating"].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredEmployees.map(u => {
                const empGoals = cycleGoals.filter(g => g.employeeId === u.id);
                const approved = empGoals.filter(g => g.status === "Approved" || g.status === "Locked");
                const avgProgress = approved.length > 0 ? Math.round(approved.reduce((s, g) => s + calculateGoalProgress(g), 0) / approved.length) : 0;
                const rating = ratings.filter(r => r.employeeId === u.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
                return (
                  <tr key={u.id} className="hover:bg-gray-50" data-testid={`perf-row-${u.id}`}>
                    <td className="px-4 py-3"><div className="flex items-center gap-2"><div className="w-6 h-6 rounded-full bg-blue-600 flex items-center justify-center"><span className="text-[9px] font-bold text-white">{u.initials}</span></div><span className="text-xs font-medium text-gray-900">{u.name}</span></div></td>
                    <td className="px-4 py-3 text-xs text-gray-500">{u.department}</td>
                    <td className="px-4 py-3 text-xs text-gray-500">{u.jobTitle}</td>
                    <td className="px-4 py-3 text-xs text-gray-700">{empGoals.length}</td>
                    <td className="px-4 py-3 text-xs text-gray-700">{approved.length}</td>
                    <td className="px-4 py-3 w-28"><GoalProgressBar progress={avgProgress} size="sm" /></td>
                    <td className="px-4 py-3 text-xs font-semibold text-amber-500">{rating ? `${rating.rating}/5` : "—"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Department Analytics */}
      {activeReport === "department-analytics" && (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden" data-testid="report-department-analytics">
          <div className="px-5 py-3 border-b border-gray-100 bg-gray-50">
            <p className="text-xs font-medium text-gray-600">Department Analytics Summary</p>
          </div>
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                {["Department", "Employees", "Total Goals", "Approved", "Avg Progress"].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {deptSummary.map(d => (
                <tr key={d.dept} className="hover:bg-gray-50" data-testid={`dept-row-${d.dept}`}>
                  <td className="px-4 py-3 text-xs font-medium text-gray-900">{d.dept}</td>
                  <td className="px-4 py-3 text-xs text-gray-700">{d.employees}</td>
                  <td className="px-4 py-3 text-xs text-gray-700">{d.totalGoals}</td>
                  <td className="px-4 py-3 text-xs text-gray-700">{d.approved}</td>
                  <td className="px-4 py-3 w-36"><GoalProgressBar progress={d.avgProgress} size="sm" /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
