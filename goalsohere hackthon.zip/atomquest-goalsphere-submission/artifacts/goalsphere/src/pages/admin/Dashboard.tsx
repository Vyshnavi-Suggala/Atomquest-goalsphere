import { useMemo } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Users, Target, TrendingUp, AlertTriangle, Building, BarChart3, ChevronRight, Award } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";
import { useData } from "@/contexts/DataContext";
import { calculateGoalProgress, calculateOverallProgress } from "@/lib/progress";
import { KPICard } from "@/components/shared/KPICard";
import { GoalProgressBar } from "@/components/shared/GoalProgressBar";
import { CycleStatusBadge } from "@/components/shared/StatusBadge";
import { PageHeader } from "@/components/shared/PageHeader";

const COLORS = ["#2563eb", "#16a34a", "#d97706", "#7c3aed", "#dc2626"];

export default function AdminDashboard() {
  const { users, goals, cycles, ratings } = useData();

  const employees = users.filter(u => u.role === "employee");
  const activeCycle = cycles.find(c => c.status === "Active");
  const cycleGoals = goals.filter(g => g.cycleId === (activeCycle?.id ?? "cy3"));

  const submitted = cycleGoals.filter(g => g.status === "Submitted").length;
  const approved = cycleGoals.filter(g => g.status === "Approved" || g.status === "Locked").length;
  const orgProgress = useMemo(() => {
    const empProgresses = employees.map(u => calculateOverallProgress(cycleGoals.filter(g => g.employeeId === u.id)));
    return empProgresses.length > 0 ? Math.round(empProgresses.reduce((s, p) => s + p, 0) / empProgresses.length) : 0;
  }, [employees, cycleGoals]);

  const escalations = useMemo(() => {
    const notSubmitted = employees.filter(u => cycleGoals.filter(g => g.employeeId === u.id).length === 0).length;
    const pendingApprovals = cycleGoals.filter(g => g.status === "Submitted").length;
    return notSubmitted + pendingApprovals;
  }, [employees, cycleGoals]);

  const depts = Array.from(new Set(employees.map(u => u.department)));
  const deptData = useMemo(() => depts.map(dept => {
    const deptUsers = employees.filter(u => u.department === dept);
    const deptGoals = cycleGoals.filter(g => deptUsers.some(u => u.id === g.employeeId));
    const progress = deptUsers.length > 0
      ? Math.round(deptUsers.reduce((s, u) => s + calculateOverallProgress(deptGoals.filter(g => g.employeeId === u.id)), 0) / deptUsers.length)
      : 0;
    return { dept, progress, employees: deptUsers.length, goals: deptGoals.length };
  }), [depts, employees, cycleGoals]);

  const thrustData = useMemo(() => {
    const counts: Record<string, number> = {};
    cycleGoals.forEach(g => { counts[g.thrustArea] = (counts[g.thrustArea] ?? 0) + 1; });
    return Object.entries(counts).map(([name, value]) => ({ name: name.split(" ").slice(-1)[0], value }));
  }, [cycleGoals]);

  // Top performers
  const topPerformers = useMemo(() => {
    return employees
      .map(u => {
        const empGoals = cycleGoals.filter(g => g.employeeId === u.id);
        const progress = calculateOverallProgress(empGoals);
        const rating = ratings.filter(r => r.employeeId === u.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
        return { user: u, progress, rating: rating?.rating ?? 0 };
      })
      .sort((a, b) => b.progress - a.progress || b.rating - a.rating)
      .slice(0, 3);
  }, [employees, cycleGoals, ratings]);

  return (
    <div data-testid="admin-dashboard">
      <PageHeader
        title="Organization Overview"
        subtitle={`${activeCycle?.name} — ${activeCycle?.phase?.replace(/([A-Z])/g, " $1").trim()}`}
        actions={
          <Link href="/admin/analytics">
            <a className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors">
              <BarChart3 size={14} />
              Analytics
            </a>
          </Link>
        }
      />

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <KPICard title="Total Employees" value={employees.length} subtitle="Active users" icon={<Users size={18} className="text-blue-600" />} iconBg="bg-blue-50" />
        <KPICard title="Goals Submitted" value={submitted + approved} subtitle={`${approved} approved`} icon={<Target size={18} className="text-green-600" />} iconBg="bg-green-50" />
        <KPICard title="Org Progress" value={`${orgProgress}%`} subtitle="Weighted average" icon={<TrendingUp size={18} className="text-purple-600" />} iconBg="bg-purple-50" />
        <KPICard title="Active Escalations" value={escalations} subtitle="Requires attention" icon={<AlertTriangle size={18} className="text-red-600" />} iconBg="bg-red-50" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Department Performance */}
        <div className="lg:col-span-2 bg-white rounded-lg border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2"><Building size={14} />Department Performance</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={deptData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="dept" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} unit="%" />
              <Tooltip formatter={(v: number) => `${v}%`} />
              <Bar dataKey="progress" fill="#2563eb" radius={[4, 4, 0, 0]} name="Progress %" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Goal Distribution by Thrust Area */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">Goals by Thrust Area</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={thrustData} cx="50%" cy="50%" innerRadius={45} outerRadius={80} dataKey="value" paddingAngle={2}>
                {thrustData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Legend iconSize={10} wrapperStyle={{ fontSize: 11 }} />
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Cycle Overview */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">Goal Cycle Status</h3>
          <div className="space-y-3">
            {cycles.map(cycle => (
              <div key={cycle.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg" data-testid={`cycle-row-${cycle.id}`}>
                <div>
                  <p className="text-sm font-medium text-gray-900">{cycle.name}</p>
                  <p className="text-xs text-gray-500">{cycle.phase.replace(/([A-Z])/g, " $1").trim()}</p>
                </div>
                <CycleStatusBadge status={cycle.status} />
              </div>
            ))}
          </div>
          <Link href="/admin/cycles">
            <a className="mt-3 flex items-center gap-1 text-xs text-blue-600 hover:text-blue-700">
              Manage cycles <ChevronRight size={12} />
            </a>
          </Link>
        </div>

        {/* Top Performers */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-gray-700 flex items-center gap-2"><Award size={14} className="text-amber-500" />Top Performers</h3>
            <Link href="/leaderboard">
              <a className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1">Full Leaderboard <ChevronRight size={12} /></a>
            </Link>
          </div>
          <div className="space-y-3">
            {topPerformers.map(({ user, progress, rating }, i) => (
              <motion.div key={user.id} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg" data-testid={`top-performer-${user.id}`}>
                <span className={`text-base font-bold w-6 ${i === 0 ? "text-amber-500" : i === 1 ? "text-gray-400" : "text-amber-700"}`}>{["#1", "#2", "#3"][i]}</span>
                <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
                  <span className="text-xs font-bold text-white">{user.initials}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900">{user.name}</p>
                  <GoalProgressBar progress={progress} size="sm" className="mt-1" />
                </div>
                {rating > 0 && (
                  <div className="text-center">
                    <p className="text-xs font-bold text-amber-500">{rating}/5</p>
                    <p className="text-[10px] text-gray-400">Rating</p>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
