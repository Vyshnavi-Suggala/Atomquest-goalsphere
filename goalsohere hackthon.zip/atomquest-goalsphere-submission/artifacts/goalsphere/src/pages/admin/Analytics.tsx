import { useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, Legend, ComposedChart, Area } from "recharts";
import { useData } from "@/contexts/DataContext";
import { calculateGoalProgress, calculateOverallProgress } from "@/lib/progress";
import { PageHeader } from "@/components/shared/PageHeader";

const COLORS = ["#2563eb", "#16a34a", "#d97706", "#7c3aed", "#dc2626", "#0891b2"];

export default function AdminAnalytics() {
  const { users, goals, cycles, ratings } = useData();

  const employees = users.filter(u => u.role === "employee");
  const activeCycle = cycles.find(c => c.status === "Active");
  const cycleGoals = goals.filter(g => g.cycleId === (activeCycle?.id ?? "cy3"));

  const depts = Array.from(new Set(employees.map(u => u.department)));

  const deptData = useMemo(() => depts.map(dept => {
    const deptUsers = employees.filter(u => u.department === dept);
    const deptGoals = cycleGoals.filter(g => deptUsers.some(u => u.id === g.employeeId));
    const approved = deptGoals.filter(g => g.status === "Approved" || g.status === "Locked");
    const progress = deptUsers.length > 0
      ? Math.round(deptUsers.reduce((s, u) => s + calculateOverallProgress(deptGoals.filter(g => g.employeeId === u.id)), 0) / deptUsers.length)
      : 0;
    return { dept, progress, totalGoals: deptGoals.length, approvedGoals: approved.length };
  }), [depts, employees, cycleGoals]);

  const qoqData = [
    { quarter: "Q1 2025", Engineering: 78, Sales: 82, Marketing: 75 },
    { quarter: "Q2 2025", Engineering: 83, Sales: 85, Marketing: 79 },
    { quarter: "Q3 2025", Engineering: 74, Sales: 80, Marketing: 76 },
  ];

  const thrustData = useMemo(() => {
    const counts: Record<string, number> = {};
    cycleGoals.forEach(g => { counts[g.thrustArea] = (counts[g.thrustArea] ?? 0) + 1; });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [cycleGoals]);

  const goalStatusData = useMemo(() => {
    const counts: Record<string, number> = {};
    cycleGoals.forEach(g => { counts[g.status] = (counts[g.status] ?? 0) + 1; });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [cycleGoals]);

  const managerEffectiveness = useMemo(() => {
    const managers = users.filter(u => u.role === "manager");
    return managers.map(m => {
      const team = employees.filter(u => u.managerId === m.id);
      const teamGoals = cycleGoals.filter(g => team.some(u => u.id === g.employeeId));
      const approvalRate = teamGoals.length > 0
        ? Math.round((teamGoals.filter(g => g.status === "Approved" || g.status === "Locked").length / teamGoals.length) * 100)
        : 0;
      const pending = teamGoals.filter(g => g.status === "Submitted").length;
      const avgProgress = team.length > 0
        ? Math.round(team.reduce((s, u) => s + calculateOverallProgress(teamGoals.filter(g => g.employeeId === u.id)), 0) / team.length)
        : 0;
      return { name: m.name, dept: m.department, teamSize: team.length, approvalRate, pending, avgProgress };
    });
  }, [users, employees, cycleGoals]);

  const empProgressData = useMemo(() =>
    employees.map(u => ({
      name: u.name.split(" ")[0],
      progress: calculateOverallProgress(cycleGoals.filter(g => g.employeeId === u.id)),
      dept: u.department,
    })).sort((a, b) => b.progress - a.progress),
    [employees, cycleGoals]
  );

  return (
    <div data-testid="admin-analytics">
      <PageHeader title="Analytics Dashboard" subtitle="Organization-wide performance insights" />

      {/* QoQ Trend */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5 mb-6">
        <h3 className="text-sm font-semibold text-gray-700 mb-4">Quarter-over-Quarter Progress by Department</h3>
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={qoqData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis dataKey="quarter" tick={{ fontSize: 11 }} />
            <YAxis tick={{ fontSize: 11 }} domain={[60, 100]} unit="%" />
            <Tooltip formatter={(v: number) => `${v}%`} />
            <Legend iconSize={10} wrapperStyle={{ fontSize: 11 }} />
            {depts.map((dept, i) => (
              <Line key={dept} type="monotone" dataKey={dept} stroke={COLORS[i % COLORS.length]} strokeWidth={2} dot={{ r: 4 }} />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Department Performance */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">Department Performance Comparison</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={deptData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="dept" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} unit="%" />
              <Tooltip formatter={(v: number) => `${v}%`} />
              <Bar dataKey="progress" fill="#2563eb" radius={[4, 4, 0, 0]} name="Avg Progress" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Goal Distribution */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">Goal Distribution by Thrust Area</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={thrustData} cx="50%" cy="50%" innerRadius={50} outerRadius={85} dataKey="value" paddingAngle={2}>
                {thrustData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Legend iconSize={10} wrapperStyle={{ fontSize: 11 }} />
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Employee Progress */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">Individual Employee Progress</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={empProgressData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 10 }} unit="%" />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 10 }} width={55} />
              <Tooltip formatter={(v: number) => `${v}%`} />
              <Bar dataKey="progress" fill="#2563eb" radius={[0, 4, 4, 0]} name="Progress" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Goal Status Distribution */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">Goal Status Distribution</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={goalStatusData} cx="50%" cy="50%" outerRadius={85} dataKey="value" paddingAngle={2}>
                {goalStatusData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Legend iconSize={10} wrapperStyle={{ fontSize: 11 }} />
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Manager Effectiveness */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100">
          <h3 className="text-sm font-semibold text-gray-700">Manager Effectiveness</h3>
        </div>
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              {["Manager", "Department", "Team Size", "Approval Rate", "Pending", "Team Avg Progress"].map(h => (
                <th key={h} className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {managerEffectiveness.map((m, idx) => (
              <tr key={m.name} className="hover:bg-gray-50" data-testid={`manager-row-${idx}`}>
                <td className="px-4 py-3 font-medium text-gray-900 text-xs">{m.name}</td>
                <td className="px-4 py-3 text-xs text-gray-500">{m.dept}</td>
                <td className="px-4 py-3 text-xs text-gray-700">{m.teamSize}</td>
                <td className="px-4 py-3">
                  <span className={`text-xs font-semibold ${m.approvalRate >= 80 ? "text-green-600" : m.approvalRate >= 50 ? "text-amber-600" : "text-red-500"}`}>{m.approvalRate}%</span>
                </td>
                <td className="px-4 py-3 text-xs text-gray-700">{m.pending}</td>
                <td className="px-4 py-3 text-xs font-semibold text-blue-600">{m.avgProgress}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
