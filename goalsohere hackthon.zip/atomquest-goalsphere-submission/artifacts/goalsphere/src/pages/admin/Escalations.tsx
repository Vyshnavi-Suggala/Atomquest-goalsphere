import { useMemo } from "react";
import { motion } from "framer-motion";
import { AlertTriangle, Bell, Clock, UserX, CheckSquare } from "lucide-react";
import { useData } from "@/contexts/DataContext";
import { useAuth } from "@/contexts/AuthContext";
import { PageHeader } from "@/components/shared/PageHeader";

export default function AdminEscalations() {
  const { currentUser } = useAuth();
  const { users, goals, cycles, addNotification } = useData();

  const employees = users.filter(u => u.role === "employee");
  const activeCycle = cycles.find(c => c.status === "Active");
  const cycleGoals = goals.filter(g => g.cycleId === (activeCycle?.id ?? "cy3"));

  const escalations = useMemo(() => {
    const list: Array<{ type: string; priority: "High" | "Medium" | "Low"; user: typeof users[0]; detail: string; userId: string }> = [];

    employees.forEach(u => {
      const empGoals = cycleGoals.filter(g => g.employeeId === u.id);
      const submitted = empGoals.filter(g => g.status !== "Draft").length;

      if (empGoals.length === 0) {
        list.push({ type: "Goals Not Submitted", priority: "High", user: u, detail: "No goals created for this cycle", userId: u.id });
      } else if (submitted === 0) {
        list.push({ type: "Goals Not Submitted", priority: "High", user: u, detail: `${empGoals.length} goals in Draft — not submitted for approval`, userId: u.id });
      }

      const overdue = empGoals.filter(g => (g.status === "Approved" || g.status === "Locked") && new Date(g.deadline) < new Date() && g.achievementStatus !== "Completed");
      if (overdue.length > 0) {
        list.push({ type: "Check-in Overdue", priority: "Medium", user: u, detail: `${overdue.length} goals past deadline without completion`, userId: u.id });
      }
    });

    const managers = users.filter(u => u.role === "manager");
    managers.forEach(m => {
      const teamGoals = cycleGoals.filter(g => employees.filter(u => u.managerId === m.id).some(u => u.id === g.employeeId));
      const pending = teamGoals.filter(g => g.status === "Submitted").length;
      if (pending > 0) {
        list.push({ type: "Approval Pending", priority: pending > 3 ? "High" : "Medium", user: m, detail: `${pending} goal${pending > 1 ? "s" : ""} awaiting approval from this manager`, userId: m.id });
      }
    });

    return list;
  }, [employees, users, cycleGoals]);

  const sendReminder = (userId: string, type: string) => {
    addNotification({
      id: `n-${Date.now()}`,
      userId,
      type: "escalation",
      message: `Reminder: ${type} — action required for ${activeCycle?.name}.`,
      read: false,
      createdAt: new Date().toISOString().split("T")[0],
    });
  };

  const priorityConfig = {
    High:   { className: "bg-red-50 text-red-700 border-red-200", dot: "bg-red-500" },
    Medium: { className: "bg-amber-50 text-amber-700 border-amber-200", dot: "bg-amber-500" },
    Low:    { className: "bg-blue-50 text-blue-700 border-blue-200", dot: "bg-blue-500" },
  };

  const typeIcons = {
    "Goals Not Submitted": UserX,
    "Approval Pending": Clock,
    "Check-in Overdue": CheckSquare,
  };

  const high = escalations.filter(e => e.priority === "High");
  const medium = escalations.filter(e => e.priority === "Medium");

  return (
    <div data-testid="admin-escalations">
      <PageHeader title="Escalations" subtitle={`${escalations.length} active escalations requiring attention`} />

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {[
          { label: "High Priority", count: high.length, color: "text-red-600", bg: "bg-red-50 border-red-200" },
          { label: "Medium Priority", count: medium.length, color: "text-amber-600", bg: "bg-amber-50 border-amber-200" },
          { label: "Total Escalations", count: escalations.length, color: "text-gray-700", bg: "bg-white border-gray-200" },
        ].map(s => (
          <div key={s.label} className={`rounded-lg border shadow-sm p-4 ${s.bg}`}>
            <p className="text-xs text-gray-500">{s.label}</p>
            <p className={`text-2xl font-bold mt-1 ${s.color}`}>{s.count}</p>
          </div>
        ))}
      </div>

      {escalations.length === 0 ? (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-12 text-center text-gray-400">
          <AlertTriangle size={32} className="mx-auto mb-3 opacity-40" />
          <p className="text-sm">No escalations found</p>
          <p className="text-xs mt-1">All employees are on track</p>
        </div>
      ) : (
        <div className="space-y-3">
          {escalations.map((esc, idx) => {
            const config = priorityConfig[esc.priority];
            const Icon = typeIcons[esc.type as keyof typeof typeIcons] ?? AlertTriangle;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.04 }}
                className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 flex items-start gap-4"
                data-testid={`escalation-${idx}`}
              >
                <div className={`p-2.5 rounded-lg ${esc.priority === "High" ? "bg-red-50" : "bg-amber-50"} flex-shrink-0`}>
                  <Icon size={16} className={esc.priority === "High" ? "text-red-600" : "text-amber-600"} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border ${config.className}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${config.dot}`} />
                      {esc.priority}
                    </span>
                    <span className="text-xs font-medium text-gray-700">{esc.type}</span>
                  </div>
                  <p className="text-sm font-semibold text-gray-900">{esc.user.name}</p>
                  <p className="text-xs text-gray-500">{esc.user.department} · {esc.user.jobTitle}</p>
                  <p className="text-xs text-gray-600 mt-1">{esc.detail}</p>
                </div>
                <button
                  onClick={() => sendReminder(esc.userId, esc.type)}
                  className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-300 text-gray-600 text-xs font-medium rounded-lg hover:bg-gray-50 transition-colors flex-shrink-0"
                  data-testid={`button-send-reminder-${idx}`}
                >
                  <Bell size={12} />
                  Remind
                </button>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
