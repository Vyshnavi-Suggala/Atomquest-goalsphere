import { useState } from "react";
import { motion } from "framer-motion";
import { Users, Search, Eye } from "lucide-react";
import { useData } from "@/contexts/DataContext";
import { PageHeader } from "@/components/shared/PageHeader";

export default function AdminUsers() {
  const { users, goals, cycles } = useData();
  const [search, setSearch] = useState("");
  const [filterRole, setFilterRole] = useState("All");
  const [filterDept, setFilterDept] = useState("All");

  const activeCycle = cycles.find(c => c.status === "Active");
  const depts = Array.from(new Set(users.map(u => u.department)));

  const filtered = users.filter(u => {
    const matchSearch = u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase());
    const matchRole = filterRole === "All" || u.role === filterRole;
    const matchDept = filterDept === "All" || u.department === filterDept;
    return matchSearch && matchRole && matchDept;
  });

  return (
    <div data-testid="admin-users">
      <PageHeader title="User Management" subtitle={`${users.length} total users`} />

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-5">
        <div className="relative flex-1 min-w-48">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="search"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search users..."
            className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
            data-testid="input-search-users"
          />
        </div>
        <select value={filterRole} onChange={e => setFilterRole(e.target.value)} className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500" data-testid="select-filter-role">
          <option value="All">All Roles</option>
          <option value="employee">Employee</option>
          <option value="manager">Manager</option>
          <option value="admin">Admin</option>
        </select>
        <select value={filterDept} onChange={e => setFilterDept(e.target.value)} className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500" data-testid="select-filter-dept">
          <option value="All">All Departments</option>
          {depts.map(d => <option key={d} value={d}>{d}</option>)}
        </select>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              {["User", "Email", "Role", "Department", "Job Title", "Manager", "Goals", ""].map(h => (
                <th key={h} className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {filtered.map((user, idx) => {
              const manager = users.find(u => u.id === user.managerId);
              const userGoals = goals.filter(g => g.employeeId === user.id && g.cycleId === (activeCycle?.id ?? "cy3"));
              return (
                <motion.tr key={user.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: idx * 0.02 }} className="hover:bg-gray-50" data-testid={`user-row-${user.id}`}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
                        <span className="text-[10px] font-bold text-white">{user.initials}</span>
                      </div>
                      <span className="font-medium text-gray-900 text-xs">{user.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-500">{user.email}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium border ${user.role === "admin" ? "bg-purple-50 text-purple-700 border-purple-200" : user.role === "manager" ? "bg-blue-50 text-blue-700 border-blue-200" : "bg-gray-100 text-gray-600 border-gray-200"}`}>
                      {user.role}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-600">{user.department}</td>
                  <td className="px-4 py-3 text-xs text-gray-500">{user.jobTitle}</td>
                  <td className="px-4 py-3 text-xs text-gray-500">{manager?.name ?? "—"}</td>
                  <td className="px-4 py-3 text-xs font-medium text-gray-700">{userGoals.length}</td>
                  <td className="px-4 py-3">
                    <button className="p-1 text-gray-400 hover:text-blue-600 rounded" data-testid={`button-view-user-${user.id}`}>
                      <Eye size={14} />
                    </button>
                  </td>
                </motion.tr>
              );
            })}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div className="text-center py-12 text-gray-400">
            <Users size={28} className="mx-auto mb-2 opacity-40" />
            <p className="text-sm">No users found</p>
          </div>
        )}
      </div>
    </div>
  );
}
