import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { CheckCircle, XCircle, RotateCcw, Edit2, Save, X } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useData } from "@/contexts/DataContext";
import { PageHeader } from "@/components/shared/PageHeader";
import { GoalStatusBadge } from "@/components/shared/StatusBadge";
import type { GoalStatus } from "@/data/mockData";

export default function ManagerApprovals() {
  const { currentUser } = useAuth();
  const { users, goals, cycles, updateGoal, addAuditLog, addNotification } = useData();
  const [filter, setFilter] = useState<string>("Submitted");
  const [editingGoal, setEditingGoal] = useState<string | null>(null);
  const [editData, setEditData] = useState<{ target: string; weightage: string; comments: string }>({ target: "", weightage: "", comments: "" });
  const [actionComments, setActionComments] = useState<Record<string, string>>({});

  const myTeam = useMemo(() => users.filter(u => u.managerId === currentUser?.id), [users, currentUser]);
  const activeCycle = cycles.find(c => c.status === "Active");

  const teamGoals = useMemo(() =>
    goals.filter(g => myTeam.some(u => u.id === g.employeeId) && g.cycleId === (activeCycle?.id ?? "cy3")),
    [goals, myTeam, activeCycle]
  );

  const filteredGoals = filter === "All" ? teamGoals : teamGoals.filter(g => g.status === filter);

  const handleAction = (goalId: string, action: "approve" | "reject" | "rework") => {
    const comment = actionComments[goalId] ?? "";
    const goal = goals.find(g => g.id === goalId);
    if (!goal) return;

    const statusMap: Record<string, GoalStatus> = { approve: "Approved", reject: "Rejected", rework: "Rework" };
    const newStatus = statusMap[action];

    updateGoal(goalId, { status: newStatus, managerComments: comment || goal.managerComments });

    addAuditLog({
      id: `al-${Date.now()}`, userId: currentUser!.id,
      action: action === "approve" ? "Goal Approved" : action === "reject" ? "Goal Rejected" : "Goal Returned for Rework",
      entityType: "Goal", entityId: goalId,
      details: `Manager ${currentUser!.name} ${action}d goal: ${goal.title}. ${comment ? "Comment: " + comment : ""}`,
      timestamp: new Date().toISOString()
    });

    addNotification({
      id: `n-${Date.now()}`, userId: goal.employeeId,
      type: action === "approve" ? "approval" : action === "reject" ? "rejection" : "rework",
      message: action === "approve"
        ? `Your goal "${goal.title}" has been approved by ${currentUser!.name}.`
        : action === "reject"
          ? `Your goal "${goal.title}" was rejected. Manager comment: ${comment}`
          : `Your goal "${goal.title}" needs revision. Manager comment: ${comment}`,
      read: false, createdAt: new Date().toISOString().split("T")[0], relatedGoalId: goalId
    });

    setActionComments(prev => { const n = { ...prev }; delete n[goalId]; return n; });
  };

  const startEdit = (goalId: string) => {
    const g = goals.find(goal => goal.id === goalId);
    if (!g) return;
    setEditingGoal(goalId);
    setEditData({ target: String(g.target), weightage: String(g.weightage), comments: g.managerComments ?? "" });
  };

  const saveEdit = (goalId: string) => {
    updateGoal(goalId, {
      target: Number(editData.target),
      weightage: Number(editData.weightage),
      managerComments: editData.comments,
    });
    setEditingGoal(null);
  };

  return (
    <div data-testid="manager-approvals">
      <PageHeader
        title="Goal Approvals"
        subtitle={`Review submitted goals from your team`}
      />

      <div className="flex gap-1 mb-5 bg-gray-100 p-1 rounded-lg w-fit">
        {["Submitted", "All", "Approved", "Rejected", "Rework"].map(s => (
          <button key={s} onClick={() => setFilter(s)} className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${filter === s ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`} data-testid={`filter-approval-${s.toLowerCase()}`}>
            {s}
            <span className="ml-1 text-[10px] text-gray-400">({(s === "All" ? teamGoals : teamGoals.filter(g => g.status === s)).length})</span>
          </button>
        ))}
      </div>

      {filteredGoals.length === 0 ? (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-12 text-center text-gray-400">
          <CheckCircle size={32} className="mx-auto mb-3 opacity-40" />
          <p className="text-sm">No goals to review in this filter</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredGoals.map((goal, idx) => {
            const emp = users.find(u => u.id === goal.employeeId);
            const isEditing = editingGoal === goal.id;

            return (
              <motion.div
                key={goal.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.04 }}
                className="bg-white rounded-lg border border-gray-200 shadow-sm p-5"
                data-testid={`approval-card-${goal.id}`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center">
                        <span className="text-[10px] font-bold text-white">{emp?.initials}</span>
                      </div>
                      <span className="text-xs text-gray-500">{emp?.name} · {emp?.department}</span>
                    </div>
                    <h3 className="font-semibold text-gray-900">{goal.title}</h3>
                    <p className="text-xs text-gray-500 mt-0.5">{goal.thrustArea}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <GoalStatusBadge status={goal.status} />
                    {goal.status === "Submitted" && (
                      <button onClick={() => startEdit(goal.id)} className="p-1.5 text-gray-400 hover:text-blue-600 rounded-lg hover:bg-blue-50" data-testid={`button-edit-inline-${goal.id}`}>
                        <Edit2 size={14} />
                      </button>
                    )}
                  </div>
                </div>

                <p className="text-sm text-gray-600 mb-4">{goal.description}</p>

                <div className="grid grid-cols-4 gap-3 mb-4">
                  {isEditing ? (
                    <>
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">Target</label>
                        <input type="number" value={editData.target} onChange={e => setEditData(d => ({ ...d, target: e.target.value }))} className="w-full border border-blue-300 rounded-lg px-2 py-1.5 text-sm" data-testid="input-edit-target" />
                      </div>
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">Weightage (%)</label>
                        <input type="number" min="10" max="100" value={editData.weightage} onChange={e => setEditData(d => ({ ...d, weightage: e.target.value }))} className="w-full border border-blue-300 rounded-lg px-2 py-1.5 text-sm" data-testid="input-edit-weightage" />
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="bg-gray-50 rounded-lg p-3 text-xs"><p className="text-gray-400">Target</p><p className="font-bold text-gray-900 mt-1">{goal.target.toLocaleString()}</p></div>
                      <div className="bg-gray-50 rounded-lg p-3 text-xs"><p className="text-gray-400">Weightage</p><p className="font-bold text-gray-900 mt-1">{goal.weightage}%</p></div>
                    </>
                  )}
                  <div className="bg-gray-50 rounded-lg p-3 text-xs"><p className="text-gray-400">UoM</p><p className="font-bold text-gray-900 mt-1">{goal.unitOfMeasurement}</p></div>
                  <div className="bg-gray-50 rounded-lg p-3 text-xs"><p className="text-gray-400">Deadline</p><p className="font-bold text-gray-900 mt-1">{goal.deadline}</p></div>
                </div>

                {isEditing ? (
                  <div className="space-y-3">
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Manager Comments</label>
                      <textarea value={editData.comments} onChange={e => setEditData(d => ({ ...d, comments: e.target.value }))} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm resize-none" rows={2} data-testid="input-edit-comments" />
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => saveEdit(goal.id)} className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700" data-testid={`button-save-edit-${goal.id}`}>
                        <Save size={13} /> Save Changes
                      </button>
                      <button onClick={() => setEditingGoal(null)} className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-300 text-gray-600 text-sm rounded-lg hover:bg-gray-50">
                        <X size={13} /> Cancel
                      </button>
                    </div>
                  </div>
                ) : goal.status === "Submitted" ? (
                  <div className="space-y-3 border-t border-gray-100 pt-4">
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Comments (required for Reject/Rework)</label>
                      <textarea
                        value={actionComments[goal.id] ?? ""}
                        onChange={e => setActionComments(prev => ({ ...prev, [goal.id]: e.target.value }))}
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm resize-none"
                        rows={2}
                        placeholder="Add feedback for the employee..."
                        data-testid={`textarea-comments-${goal.id}`}
                      />
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => handleAction(goal.id, "approve")} className="flex items-center gap-1.5 px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700" data-testid={`button-approve-${goal.id}`}>
                        <CheckCircle size={14} /> Approve
                      </button>
                      <button onClick={() => handleAction(goal.id, "rework")} className="flex items-center gap-1.5 px-4 py-2 bg-orange-500 text-white text-sm font-medium rounded-lg hover:bg-orange-600" data-testid={`button-rework-${goal.id}`}>
                        <RotateCcw size={14} /> Return for Rework
                      </button>
                      <button onClick={() => handleAction(goal.id, "reject")} className="flex items-center gap-1.5 px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700" data-testid={`button-reject-${goal.id}`}>
                        <XCircle size={14} /> Reject
                      </button>
                    </div>
                  </div>
                ) : goal.managerComments ? (
                  <div className="mt-3 p-3 bg-gray-50 rounded-lg border border-gray-100 text-xs text-gray-600">
                    <span className="font-medium text-gray-700">Manager comments: </span>{goal.managerComments}
                  </div>
                ) : null}
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
