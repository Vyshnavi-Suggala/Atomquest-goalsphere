import { useMemo } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Users, ClipboardList, TrendingUp, CheckCircle, ChevronRight, Clock } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, Legend } from "recharts";
import { useAuth } from "@/contexts/AuthContext";
import { useData } from "@/contexts/DataContext";
import { calculateOverallProgress } from "@/lib/progress";
import { KPICard } from "@/components/shared/KPICard";
import { GoalStatusBadge } from "@/components/shared/StatusBadge";
import { GoalProgressBar } from "@/components/shared/GoalProgressBar";
import { PageHeader } from "@/components/shared/PageHeader";

export default function ManagerDashboard() {
  const { currentUser } = useAuth();
  const { users, goals, cycles } = useData();

  const myTeam = useMemo(() => users.filter(u => u.managerId === currentUser?.id && u.role === "employee"), [users, currentUser]);
  const activeCycle = cycles.find(c => c.status === "Active");

  const teamGoals = useMemo(() =>
    goals.filter(g => myTeam.some(u => u.id === g.employeeId) && g.cycleId === (activeCycle?.id ?? "cy3")),
    [goals, myTeam, activeCycle]
  );
  const pendingApprovals = teamGoals.filter(g => g.status === "Submitted");
  const approvedGoals = teamGoals.filter(g => g.status === "Approved" || g.status === "Locked");

  const teamAvgProgress = useMemo(() => {
    if (myTeam.length === 0) return 0;
    const progresses = myTeam.map(u => {
      const empGoals = teamGoals.filter(g => g.employeeId === u.id);
      return calculateOverallProgress(empGoals);
    });
    return Math.round(progresses.reduce((s, p) => s + p, 0) / progresses.length);
  }, [myTeam, teamGoals]);

  const teamTableData = useMemo(() =>
    myTeam.map(u => {
      const empGoals = teamGoals.filter(g => g.employeeId === u.id);
      const progress = calculateOverallProgress(empGoals);
      const pending = empGoals.filter(g => g.status === "Submitted").length;
      return { user: u, goals: empGoals.length, progress, pending };
    }),
    [myTeam, teamGoals]
  );

  const barData = useMemo(() =>
    myTeam.map(u => {
      const empGoals = teamGoals.filter(g => g.employeeId === u.id);
      return { name: u.name.split(" ")[0], progress: calculateOverallProgress(empGoals), goals: empGoals.filter(g => g.status === "Approved" || g.status === "Locked").length };
    }),
    [myTeam, teamGoals]
  );

  const trendData = [
    { quarter: "Q1", progress: 78 },
    { quarter: "Q2", progress: 83 },
    { quarter: "Q3", progress: teamAvgProgress },
  ];

  return (
    <div data-testid="manager-dashboard">
      <PageHeader
        title={`Team Dashboard — ${currentUser?.name.split(" ")[0]}`}
        subtitle={`${myTeam.length} direct reports · ${activeCycle?.name}`}
        actions={
          <Link href="/manager/approvals">
            <a className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors" data-testid="link-view-approvals">
              <ClipboardList size={14} />
              Review Approvals {pendingApprovals.length > 0 && <span className="bg-white text-blue-600 text-[10px] font-bold rounded-full px-1.5">{pendingApprovals.length}</span>}
            </a>
          </Link>
        }
      />

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <KPICard title="Team Size" value={myTeam.length} subtitle="Direct reports" icon={<Users size={18} className="text-blue-600" />} iconBg="bg-blue-50" />
        <KPICard title="Pending Approvals" value={pendingApprovals.length} subtitle="Awaiting review" icon={<ClipboardList size={18} className="text-amber-600" />} iconBg="bg-amber-50" />
        <KPICard title="Team Avg Progress" value={`${teamAvgProgress}%`} subtitle="Approved goals" icon={<TrendingUp size={18} className="text-green-600" />} iconBg="bg-green-50" />
        <KPICard title="Goals Approved" value={approvedGoals.length} subtitle="This cycle" icon={<CheckCircle size={18} className="text-purple-600" />} iconBg="bg-purple-50" />
      </div>

      {/* Pending Approvals Quick View */}
      {pendingApprovals.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-5 mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-amber-800 flex items-center gap-2">
              <Clock size={14} />
              Pending Approvals — Action Required
            </h3>
            <Link href="/manager/approvals">
              <a className="text-xs text-amber-700 hover:text-amber-900 flex items-center gap-1" data-testid="link-all-approvals">View all <ChevronRight size={12} /></a>
            </Link>
          </div>
          <div className="space-y-2">
            {pendingApprovals.slice(0, 3).map(g => {
              const emp = users.find(u => u.id === g.employeeId);
              return (
                <div key={g.id} className="flex items-center justify-between bg-white p-3 rounded-lg border border-amber-200" data-testid={`pending-approval-${g.id}`}>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{g.title}</p>
                    <p className="text-xs text-gray-500">{emp?.name} · {g.thrustArea} · {g.weightage}%</p>
                  </div>
                  <Link href="/manager/approvals">
                    <a className="px-3 py-1 bg-blue-600 text-white text-xs font-medium rounded-lg hover:bg-blue-700">Review</a>
                  </Link>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Team Performance Bar Chart */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">Team Progress Overview</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={barData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} unit="%" />
              <Tooltip formatter={(v: number) => `${v}%`} />
              <Bar dataKey="progress" fill="#2563eb" radius={[4, 4, 0, 0]} name="Progress %" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Team Trend */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">Team Progress Trend</h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="quarter" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} unit="%" />
              <Tooltip formatter={(v: number) => `${v}%`} />
              <Line type="monotone" dataKey="progress" stroke="#2563eb" strokeWidth={2} dot={{ r: 4 }} name="Avg Progress" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Team Status Table */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100">
          <h3 className="text-sm font-semibold text-gray-700">Team Member Status</h3>
        </div>
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              {["Employee", "Department", "Goals", "Pending", "Progress", "Action"].map(h => (
                <th key={h} className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {teamTableData.map(({ user, goals: goalCount, progress, pending }, idx) => (
              <motion.tr
                key={user.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: idx * 0.05 }}
                className="hover:bg-gray-50"
                data-testid={`team-row-${user.id}`}
              >
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center">
                      <span className="text-[10px] font-bold text-white">{user.initials}</span>
                    </div>
                    <div>
                      <p className="font-medium text-gray-900 text-xs">{user.name}</p>
                      <p className="text-[10px] text-gray-400">{user.jobTitle}</p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 text-xs text-gray-500">{user.department}</td>
                <td className="px-4 py-3 text-xs font-medium text-gray-700">{goalCount}</td>
                <td className="px-4 py-3">
                  {pending > 0 ? (
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-amber-50 text-amber-700 border border-amber-200">{pending} pending</span>
                  ) : (
                    <span className="text-xs text-gray-400">None</span>
                  )}
                </td>
                <td className="px-4 py-3 w-36">
                  <GoalProgressBar progress={progress} size="sm" />
                </td>
                <td className="px-4 py-3">
                  <Link href="/manager/team">
                    <a className="text-xs text-blue-600 hover:underline" data-testid={`link-view-employee-${user.id}`}>View Goals</a>
                  </Link>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
