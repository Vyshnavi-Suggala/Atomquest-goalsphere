import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { Users, ChevronDown, ChevronUp } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useData } from "@/contexts/DataContext";
import { calculateGoalProgress, calculateOverallProgress } from "@/lib/progress";
import { GoalStatusBadge, AchievementStatusBadge } from "@/components/shared/StatusBadge";
import { GoalProgressBar } from "@/components/shared/GoalProgressBar";
import { PageHeader } from "@/components/shared/PageHeader";

export default function ManagerTeam() {
  const { currentUser } = useAuth();
  const { users, goals, cycles } = useData();
  const [expanded, setExpanded] = useState<string | null>(null);

  const myTeam = useMemo(() => users.filter(u => u.managerId === currentUser?.id && u.role === "employee"), [users, currentUser]);
  const activeCycle = cycles.find(c => c.status === "Active");

  return (
    <div data-testid="manager-team">
      <PageHeader title="My Team" subtitle={`${myTeam.length} direct reports — ${activeCycle?.name}`} />

      <div className="space-y-3">
        {myTeam.map((member, idx) => {
          const empGoals = goals.filter(g => g.employeeId === member.id && g.cycleId === (activeCycle?.id ?? "cy3"));
          const approvedGoals = empGoals.filter(g => g.status === "Approved" || g.status === "Locked");
          const progress = calculateOverallProgress(empGoals);
          const isExpanded = expanded === member.id;

          return (
            <motion.div key={member.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.05 }} className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden" data-testid={`team-member-${member.id}`}>
              <button className="w-full flex items-center gap-4 p-5 text-left hover:bg-gray-50 transition-colors" onClick={() => setExpanded(isExpanded ? null : member.id)} data-testid={`button-expand-${member.id}`}>
                <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
                  <span className="text-sm font-bold text-white">{member.initials}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-gray-900">{member.name}</p>
                  <p className="text-xs text-gray-500">{member.jobTitle} · {member.department}</p>
                </div>
                <div className="flex items-center gap-6 text-sm">
                  <div className="text-center">
                    <p className="font-bold text-gray-900">{empGoals.length}</p>
                    <p className="text-[10px] text-gray-400">Goals</p>
                  </div>
                  <div className="text-center">
                    <p className="font-bold text-gray-900">{approvedGoals.length}</p>
                    <p className="text-[10px] text-gray-400">Approved</p>
                  </div>
                  <div className="text-center w-20">
                    <p className="font-bold text-gray-900">{progress}%</p>
                    <GoalProgressBar progress={progress} showLabel={false} size="sm" className="mt-1" />
                  </div>
                </div>
                {isExpanded ? <ChevronUp size={16} className="text-gray-400" /> : <ChevronDown size={16} className="text-gray-400" />}
              </button>

              {isExpanded && (
                <div className="border-t border-gray-100 p-5">
                  {empGoals.length === 0 ? (
                    <p className="text-sm text-gray-400 text-center py-4">No goals this cycle</p>
                  ) : (
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-gray-100">
                          {["Goal", "Thrust Area", "Target", "Actual", "Progress", "Status", "Achievement"].map(h => (
                            <th key={h} className="pb-2 text-left text-xs font-medium text-gray-500">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-50">
                        {empGoals.map(g => (
                          <tr key={g.id} className="hover:bg-gray-50" data-testid={`team-goal-${g.id}`}>
                            <td className="py-2 pr-4 max-w-48">
                              <p className="text-xs font-medium text-gray-900 truncate">{g.title}</p>
                            </td>
                            <td className="py-2 pr-4 text-xs text-gray-500">{g.thrustArea.split(" ")[0]}</td>
                            <td className="py-2 pr-4 text-xs text-gray-700">{g.target.toLocaleString()}</td>
                            <td className="py-2 pr-4 text-xs text-gray-700">{g.actualAchievement?.toLocaleString() ?? "—"}</td>
                            <td className="py-2 pr-4 w-28"><GoalProgressBar progress={calculateGoalProgress(g)} size="sm" /></td>
                            <td className="py-2 pr-4"><GoalStatusBadge status={g.status} /></td>
                            <td className="py-2"><AchievementStatusBadge status={g.achievementStatus} /></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
