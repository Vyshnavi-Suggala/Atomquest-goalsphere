import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { Star, Save, MessageSquare } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useData } from "@/contexts/DataContext";
import { calculateGoalProgress } from "@/lib/progress";
import { GoalProgressBar } from "@/components/shared/GoalProgressBar";
import { AchievementStatusBadge } from "@/components/shared/StatusBadge";
import { PageHeader } from "@/components/shared/PageHeader";

function StarRating({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map(s => (
        <button key={s} onClick={() => onChange(s)} className={`transition-colors ${s <= value ? "text-amber-400" : "text-gray-200"} hover:text-amber-400`} data-testid={`star-${s}`}>
          <Star size={22} fill={s <= value ? "currentColor" : "none"} />
        </button>
      ))}
    </div>
  );
}

export default function ManagerReviews() {
  const { currentUser } = useAuth();
  const { users, goals, cycles, ratings, addRating, updateRating, addAuditLog } = useData();
  const [ratingData, setRatingData] = useState<Record<string, { rating: number; comments: string }>>({});
  const [saved, setSaved] = useState<Record<string, boolean>>({});

  const myTeam = useMemo(() => users.filter(u => u.managerId === currentUser?.id && u.role === "employee"), [users, currentUser]);
  const activeCycle = cycles.find(c => c.status === "Active");

  const getRating = (empId: string) => ratingData[empId] ?? (() => {
    const existing = ratings.find(r => r.employeeId === empId && r.cycleId === (activeCycle?.id ?? "cy3") && r.managerId === currentUser?.id);
    return { rating: existing?.rating ?? 0, comments: existing?.comments ?? "" };
  })();

  const setField = (empId: string, field: string, value: string | number) => {
    setRatingData(prev => ({ ...prev, [empId]: { ...getRating(empId), [field]: value } }));
  };

  const handleSave = (empId: string) => {
    const d = getRating(empId);
    const existing = ratings.find(r => r.employeeId === empId && r.cycleId === (activeCycle?.id ?? "cy3") && r.managerId === currentUser?.id);
    if (existing) {
      updateRating(existing.id, { rating: d.rating, comments: d.comments });
    } else {
      addRating({ id: `pr-${Date.now()}`, employeeId: empId, managerId: currentUser!.id, cycleId: activeCycle?.id ?? "cy3", rating: d.rating, comments: d.comments, createdAt: new Date().toISOString().split("T")[0] });
    }
    addAuditLog({ id: `al-${Date.now()}`, userId: currentUser!.id, action: "Performance Rated", entityType: "Rating", entityId: empId, details: `${currentUser!.name} rated ${users.find(u => u.id === empId)?.name}: ${d.rating}/5`, timestamp: new Date().toISOString() });
    setSaved(prev => ({ ...prev, [empId]: true }));
    setTimeout(() => setSaved(prev => ({ ...prev, [empId]: false })), 2000);
  };

  return (
    <div data-testid="manager-reviews">
      <PageHeader title="Quarterly Reviews" subtitle={`Review check-in data and rate your team — ${activeCycle?.name}`} />

      <div className="space-y-5">
        {myTeam.map((member, idx) => {
          const empGoals = goals.filter(g => g.employeeId === member.id && g.cycleId === (activeCycle?.id ?? "cy3") && (g.status === "Approved" || g.status === "Locked"));
          const d = getRating(member.id);

          return (
            <motion.div key={member.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.06 }} className="bg-white rounded-lg border border-gray-200 shadow-sm p-5" data-testid={`review-card-${member.id}`}>
              <div className="flex items-center gap-3 mb-4 pb-4 border-b border-gray-100">
                <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center">
                  <span className="text-sm font-bold text-white">{member.initials}</span>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{member.name}</p>
                  <p className="text-xs text-gray-500">{member.jobTitle} · {member.department}</p>
                </div>
              </div>

              {/* Planned vs Actual Table */}
              <h4 className="text-xs font-semibold text-gray-600 uppercase tracking-wide mb-3">Planned vs Actual</h4>
              {empGoals.length === 0 ? (
                <p className="text-sm text-gray-400 mb-4">No approved goals to review</p>
              ) : (
                <table className="w-full text-xs mb-5">
                  <thead className="bg-gray-50 rounded">
                    <tr className="border-b border-gray-100">
                      {["Goal", "Target", "Actual", "Progress", "Status"].map(h => (
                        <th key={h} className="px-3 py-2 text-left font-medium text-gray-500">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {empGoals.map(g => (
                      <tr key={g.id} className="hover:bg-gray-50">
                        <td className="px-3 py-2 font-medium text-gray-800 max-w-48 truncate">{g.title}</td>
                        <td className="px-3 py-2 text-gray-600">{g.target.toLocaleString()}</td>
                        <td className={`px-3 py-2 font-semibold ${g.actualAchievement !== undefined ? "text-blue-700" : "text-gray-400"}`}>{g.actualAchievement?.toLocaleString() ?? "Not set"}</td>
                        <td className="px-3 py-2 w-32"><GoalProgressBar progress={calculateGoalProgress(g)} size="sm" /></td>
                        <td className="px-3 py-2"><AchievementStatusBadge status={g.achievementStatus} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              {/* Performance Rating */}
              <div className="border-t border-gray-100 pt-4">
                <h4 className="text-xs font-semibold text-gray-600 uppercase tracking-wide mb-3 flex items-center gap-2">
                  <Star size={12} />
                  Performance Rating
                </h4>
                <div className="space-y-3">
                  <div>
                    <p className="text-xs text-gray-500 mb-2">Rating</p>
                    <StarRating value={d.rating} onChange={v => setField(member.id, "rating", v)} />
                    {d.rating > 0 && (
                      <p className="text-xs text-amber-600 mt-1">{["", "Needs Improvement", "Below Expectations", "Meets Expectations", "Exceeds Expectations", "Outstanding"][d.rating]}</p>
                    )}
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block flex items-center gap-1"><MessageSquare size={11} /> Comments</label>
                    <textarea
                      value={d.comments}
                      onChange={e => setField(member.id, "comments", e.target.value)}
                      rows={2}
                      placeholder="Add performance comments and feedback..."
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm resize-none focus:ring-2 focus:ring-blue-500"
                      data-testid={`textarea-review-comments-${member.id}`}
                    />
                  </div>
                  <button
                    onClick={() => handleSave(member.id)}
                    disabled={d.rating === 0}
                    className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${saved[member.id] ? "bg-green-600 text-white" : d.rating === 0 ? "bg-gray-100 text-gray-400 cursor-not-allowed" : "bg-blue-600 text-white hover:bg-blue-700"}`}
                    data-testid={`button-save-rating-${member.id}`}
                  >
                    <Save size={14} />
                    {saved[member.id] ? "Saved!" : "Save Rating"}
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
