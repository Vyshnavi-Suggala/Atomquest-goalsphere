# ATOMQUEST GoalSphere

**Enterprise Goal Setting & Performance Tracking Portal**  
AtomQuest Hackathon 2025 Submission

---

## Overview

GoalSphere is a professional enterprise-grade Goal Setting & Performance Tracking Portal built for AtomQuest. It enables organizations to manage employee goals, track quarterly performance, conduct check-ins, and produce executive-level analytics — all without a backend, powered entirely by React + LocalStorage with rich mock enterprise data.

Modeled after industry leaders like **Microsoft Viva Goals** and **SAP SuccessFactors**.

---

## Features Implemented

### Employee Portal
- Personal goal dashboard with KPI cards, progress charts, and deadline tracking
- Create/edit/delete goals with full validation (max 8 goals, min 10% weightage, total must = 100%)
- Submit goals for manager approval
- Quarterly check-in: update actual achievement, status, and remarks per goal
- Real-time progress calculation based on 4 Unit of Measurement types
- Notifications center with read/unread tracking and category filters

### Manager Portal
- Team dashboard with department-level analytics and approval queue
- Goal approval workflow: Approve / Return for Rework / Reject with inline comments
- Inline target and weightage editing during review
- Team member drill-down with goal-level visibility
- Quarterly performance reviews with star ratings (1–5) and written feedback

### Admin / HR Portal
- Organization-wide performance dashboard
- Analytics: QoQ trends, department comparison, thrust area distribution, manager effectiveness
- Goal cycle management: activate/close cycles, switch phases (GoalSetting → AnnualReview)
- User directory with role, department, manager hierarchy view
- Multi-format reports: Planned vs Actual, Employee Performance, Department Analytics
- CSV export for all report types
- Escalation alerts: auto-detects missing goals, pending approvals, overdue check-ins with reminder dispatch
- Full audit log with table and interactive timeline view
- Organization leaderboard with podium, department ranking, and rating distribution

### Platform
- Role-based access control (Employee / Manager / Admin)
- LocalStorage persistence with structured seed data
- Framer Motion page transitions and animated lists
- Responsive layout with collapsible sidebar
- Recharts dashboards on every page

---

## Demo Roles

| Role | Name | Email | Access |
|------|------|-------|--------|
| Employee | Sarah Johnson | sarah@atomquest.com | Personal goals, check-in, notifications |
| Manager | David Chen | david@atomquest.com | Team approvals, reviews, + employee access |
| Admin/HR | Priya Sharma | priya@atomquest.com | Full system access |

> All users are pre-loaded. Click any role card on the login screen to enter immediately — no password required.

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | React 19 + TypeScript 5.9 |
| Routing | Wouter 3.x (hash-based, no backend) |
| Styling | Tailwind CSS v4 + shadcn/ui |
| Charts | Recharts 2.x |
| Animation | Framer Motion |
| Forms | React Hook Form + Zod validation |
| State | React Context API + LocalStorage |
| Build | Vite 7.x |
| Workspace | pnpm monorepo |

---

## Mock Data Summary

- **10 users** across 5 departments (Engineering, Sales, Marketing, HR, Finance)
- **29 goals** across Q3 2025 active cycle
- **4 goal cycles** (Q1–Q4 2025)
- **7 performance ratings** from previous cycles
- **14 notifications** pre-seeded
- **13 audit log entries** demonstrating full workflow history

---

## Goal Progress Engine

| UoM | Formula |
|-----|---------|
| Numeric | `achievement / target × 100%` |
| Percentage | `target / achievement × 100%` |
| Timeline | Date-based completion tracking |
| ZeroBased | `100% if value = 0, else 0%` |

---

## Run Instructions

### Prerequisites
- Node.js 20+
- pnpm 9+

### Development

```bash
# Install dependencies
pnpm install

# Run the GoalSphere frontend
pnpm --filter @workspace/goalsphere run dev
```

The app will be available at `http://localhost:<PORT>`.

### Production Build

```bash
pnpm --filter @workspace/goalsphere run build
```

Build output is in `artifacts/goalsphere/dist/`.

### Notes
- No backend or database required — all data is stored in browser LocalStorage
- First load automatically seeds mock enterprise data
- To reset data, clear LocalStorage key `aq_seeded_v3`
- All routes are protected by role-based auth guards

---

## Project Structure

```
artifacts/goalsphere/
├── src/
│   ├── App.tsx                    # Root app with wouter routing
│   ├── data/
│   │   └── mockData.ts            # 10 users, 29 goals, 4 cycles, all seed data
│   ├── lib/
│   │   ├── storage.ts             # LocalStorage helpers
│   │   ├── progress.ts            # BRD progress calculation engine
│   │   └── csvExport.ts           # CSV report export utilities
│   ├── contexts/
│   │   ├── AuthContext.tsx        # Role-based authentication context
│   │   └── DataContext.tsx        # Global data store with CRUD operations
│   ├── components/
│   │   ├── Layout.tsx             # Collapsible sidebar + header + breadcrumb
│   │   └── shared/
│   │       ├── KPICard.tsx        # Animated metric cards
│   │       ├── GoalProgressBar.tsx
│   │       ├── StatusBadge.tsx    # Goal/Achievement/Cycle status badges
│   │       └── PageHeader.tsx
│   └── pages/
│       ├── Login.tsx              # Role selection landing page
│       ├── employee/
│       │   ├── Dashboard.tsx      # Personal KPIs, charts, deadlines
│       │   ├── Goals.tsx          # Goal table with actions
│       │   ├── GoalForm.tsx       # Create/edit with weightage validation
│       │   ├── CheckIn.tsx        # Quarterly check-in form
│       │   └── Notifications.tsx
│       ├── manager/
│       │   ├── Dashboard.tsx      # Team overview + approval queue
│       │   ├── Approvals.tsx      # Approve/reject/rework workflow
│       │   ├── Team.tsx           # Expandable team member view
│       │   └── Reviews.tsx        # Star ratings + written reviews
│       ├── admin/
│       │   ├── Dashboard.tsx      # Org-wide KPIs + top performers
│       │   ├── Analytics.tsx      # Multi-chart analytics hub
│       │   ├── Cycles.tsx         # Cycle lifecycle management
│       │   ├── Users.tsx          # User directory with filters
│       │   ├── Reports.tsx        # 3-report suite + CSV export
│       │   ├── Audit.tsx          # Table + timeline audit view
│       │   └── Escalations.tsx    # Auto-detected issues + reminders
│       └── Leaderboard.tsx        # Podium + rankings + dept comparison
```

---

## License

AtomQuest Hackathon 2025 — Internal Demo Project
